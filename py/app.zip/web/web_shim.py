# -*- coding: utf-8 -*-
"""تشغيل برنامج متابعة المهام داخل المتصفح (Pyodide) بلا خادم.

- app.py ومحركاته تعمل كما هي، والطلبات تصلها عبر عامل الخدمة (sw.js) ثم worker.js ثم handle().
- البيانات في /data (IndexedDB في متصفح المستخدم): لا يغادر الجهاز شيء.
- ما يحتاج الجهاز نفسه يُستبدل هنا:
    مسارات الملفات ونوافذ الاختيار وفتح المجلدات ← ربط الملف من المتصفح (web.js) ورفع نسخة منه
    إنشاء ملف المدرب في مجلده ← تنزيل الملف
    PDF عبر Edge ← التقرير يُفتح في المتصفح وفيه زر «طباعة / حفظ PDF»
"""
import io
import os
import shutil
import tempfile
import zipfile
from pathlib import Path

DATA = Path("/data")
os.environ["TASKS_DATA"] = str(DATA)

import app as A  # noqa: E402
from flask import jsonify, request, send_file  # noqa: E402

A.print_pdf = lambda html, pdf, timeout=60: False
A.DEFAULT_CFG["college"] = ""
app = A.app


def _web_error(msg, code=400):
    return jsonify({"ok": False, "error": msg}), code


app.view_functions["api_browse"] = lambda: _web_error("نافذة الاختيار تعمل من الصفحة نفسها في هذه النسخة")
app.view_functions["api_open"] = lambda: _web_error("فتح الملفات والمجلدات غير متاح في نسخة المتصفح")
app.view_functions["api_scan"] = lambda: _web_error("البحث في المجلدات يتم من الصفحة نفسها في هذه النسخة")
app.view_functions["api_create_file"] = lambda: _web_error("في نسخة المتصفح يُنزَّل ملف المدرب بدل إنشائه في مجلد")


def _download(path, name):
    data = Path(path).read_bytes()
    return send_file(io.BytesIO(data), as_attachment=True, download_name=name,
                       mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/api/web/template")
def web_template():
    """ملف المتابعة من القالب: باسم المدرب إن حُدد، وإلا قالب فارغ."""
    tid = request.args.get("id", "")
    c = A.cfg()
    t = next((x for x in A.trainers() if x["id"] == tid), None)
    name = t["name"] if t else ""
    out = Path(tempfile.mkdtemp()) / "t.xlsx"
    A.build_template(out, name=name, dept=c.get("dept", ""), number=(t or {}).get("number", ""),
                     unit=c.get("college", ""), sem_id=c.get("semester") or "1448_1")
    fn = f"متابعة مهام - {name}.xlsx" if name else "قالب متابعة مهام عضو هيئة التدريب.xlsx"
    resp = _download(out, fn)
    shutil.rmtree(out.parent, ignore_errors=True)
    return resp


@app.route("/api/web/backup")
def web_backup():
    """نسخة احتياطية: كل بيانات البرنامج في ملف zip واحد (بلا الذاكرة المؤقتة وملفات الإصدار والقفل، فهي تُعاد بضغطة)."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for p in DATA.rglob("*"):
            if p.is_file() and not {"cache", "issued", "locked"} & set(p.relative_to(DATA).parts):
                z.write(p, p.relative_to(DATA).as_posix())
    buf.seek(0)
    from datetime import datetime
    return send_file(buf, as_attachment=True, mimetype="application/zip",
                       download_name=f"متابعة المهام - نسخة احتياطية {datetime.now():%Y-%m-%d}.zip")


@app.route("/api/web/restore", methods=["POST"])
def web_restore():
    f = request.files.get("file")
    if not f:
        return _web_error("اختر ملف النسخة الاحتياطية")
    try:
        z = zipfile.ZipFile(io.BytesIO(f.read()))
        names = z.namelist()
    except zipfile.BadZipFile:
        return _web_error("الملف ليس نسخة احتياطية من البرنامج")
    if "trainers.json" not in names or any(n.startswith("/") or ".." in n.split("/") for n in names):
        return _web_error("الملف ليس نسخة احتياطية من البرنامج")
    _wipe()
    z.extractall(DATA)
    A._cache.clear()
    return jsonify({"ok": True, "files": len(names)})


def _wipe():
    for p in list(DATA.iterdir()):
        shutil.rmtree(p) if p.is_dir() else p.unlink()
    for d in (A.UPLOADS, A.IMG, A.REPORTS):
        d.mkdir(parents=True, exist_ok=True)


@app.route("/api/web/reset", methods=["POST"])
def web_reset():
    _wipe()
    A._cache.clear()
    return jsonify({"ok": True})


for d in (A.UPLOADS, A.IMG, A.REPORTS):
    d.mkdir(parents=True, exist_ok=True)

app.config["PROPAGATE_EXCEPTIONS"] = True
_client = app.test_client()


def handle(method, path, headers, body):
    """طلب من المتصفح ← (الحالة، الرؤوس، المحتوى bytes)."""
    hdrs = {k: v for k, v in (headers or {}).items() if k.lower() in ("content-type", "accept")}
    if body is None or type(body).__name__ == "JsNull":
        data = None
    elif hasattr(body, "to_bytes"):          # Uint8Array من JavaScript
        data = body.to_bytes()
    else:
        data = bytes(body)
    try:
        r = _client.open(path, method=method, headers=hdrs, data=data)
    except Exception as ex:  # noqa — يظهر للمستخدم بدل صفحة 500 فارغة، والتفاصيل في وحدة التحكم
        import json
        import traceback
        tb = traceback.format_exc()
        print(tb)
        msg = json.dumps({"ok": False, "error": f"خطأ داخلي: {type(ex).__name__}: {ex}"}, ensure_ascii=False)
        return 500, [("Content-Type", "application/json; charset=utf-8")], msg.encode("utf-8")
    out = r.get_data()
    h = [(k, v) for k, v in r.headers.items() if k.lower() not in ("content-length",)]
    r.close()
    return r.status_code, h, out
