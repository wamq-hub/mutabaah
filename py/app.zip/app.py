"""برنامج متابعة مهام أعضاء هيئة التدريب — خادم محلي (http://127.0.0.1:8824).

يقرأ ملفات المدربين من مساراتها (أو نسخة مرفوعة بالسحب والإفلات) ولا يكتب فيها أبداً،
ويعرض المؤشرات، ويجهّز رسائل البريد للنسخ، ويُصدر التقارير على الورق الرسمي.
"""
import datetime as dt
import json
import os
import re
import sys
import threading
import uuid
from pathlib import Path

from flask import Flask, abort, jsonify, request, send_from_directory

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

import comms  # noqa: E402
import reader  # noqa: E402
from build_template import build as build_template  # noqa: E402
from letter_pdf import print_pdf  # noqa: E402
from names import short_name  # noqa: E402

DATA = Path(os.environ.get("TASKS_DATA") or ROOT / "data")
UPLOADS = DATA / "uploads"
IMG = DATA / "cache" / "img"
REPORTS = DATA / "reports"
PORT = int(os.environ.get("TASKS_PORT", "8824"))

app = Flask(__name__, static_folder=str(ROOT / "static"), static_url_path="/static")
app.json.ensure_ascii = False
LOCK = threading.Lock()
_cache = {}  # path -> (mtime, raw)

DEFAULT_CFG = {"dept": "", "college": "الكلية التقنية بحقل", "head_name": "", "semester": "1448_1", "today": ""}


# ---------------------------------------------------------------- التخزين
def _load(name, default):
    p = DATA / name
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            pass
    return default


def _save(name, obj):
    DATA.mkdir(parents=True, exist_ok=True)
    p = DATA / name
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, p)


def cfg():
    c = dict(DEFAULT_CFG)
    c.update(_load("config.json", {}))
    return c


def trainers():
    return _load("trainers.json", [])


def today():
    t = (cfg().get("today") or "").strip()
    try:
        return dt.date.fromisoformat(t) if t else dt.date.today()
    except ValueError:
        return dt.date.today()


def file_of(tr):
    if tr.get("mode") == "upload":
        return str(UPLOADS / f"{tr['id']}.xlsx")
    return tr.get("path") or ""


def load_result(tr):
    """يرجع (res، خطأ). يُعاد استخدام القراءة ما لم يتغير الملف."""
    p = file_of(tr)
    if not p:
        return None, "لم يُحدَّد مسار الملف"
    if not os.path.exists(p):
        return None, "الملف غير موجود في المسار"
    try:
        m = os.path.getmtime(p)
        hit = _cache.get(p)
        if hit and hit[0] == m:
            raw = hit[1]
        else:
            raw = reader.read_workbook(p, img_dir=str(IMG))
            _cache[p] = (m, raw)
        # compute يعدّل القاموس؛ نعطيه نسخة جديدة كل مرة
        import copy
        return reader.compute(copy.deepcopy(raw), today()), None
    except reader.TemplateError as ex:
        return None, str(ex)
    except Exception as ex:  # ملف تالف أو مقفل
        return None, f"تعذرت قراءة الملف: {ex.__class__.__name__}"


def _jsonable(o):
    if isinstance(o, (dt.date, dt.datetime)):
        return o.isoformat()
    if isinstance(o, dict):
        return {k: _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_jsonable(v) for v in o]
    return o


def _task_view(t):
    keys = ["id", "week", "week_title", "sheet", "section", "kind", "title", "due", "carry", "eval", "status", "done",
            "evidence", "evidence_url", "approval", "head_ev", "head_ev_url", "override", "notes", "pics", "head_pics",
            "speed", "speed_auto", "overdue", "has_evidence", "approved_done", "pending_approval"]
    return {k: t.get(k) for k in keys}


def summary_of(tr, res, err):
    out = {"id": tr["id"], "name": tr["name"], "short": short_name(tr["name"]), "email": tr.get("email", ""),
           "mode": tr.get("mode", "path"), "path": file_of(tr), "error": err}
    if res:
        cur = res["current_week"]
        w = next((x for x in res["weeks"] if x["n"] == cur), None)
        out.update({
            "file_name": res["info"].get("name"), "mtime": dt.datetime.fromtimestamp(res["mtime"]).strftime("%Y-%m-%d %H:%M"),
            "weeks": [dict(x["kpi"], n=x["n"], title=x["title"], started=x["started"]) for x in res["weeks"]],
            "total": res["total"], "current": w["kpi"] if w else None,
            "overdue": len(res["overdue"]), "no_evidence": len(res["no_evidence"]),
            "pending_approval": len(res["pending_approval"]), "no_date": len(res["no_date"]),
        })
    return out


# ---------------------------------------------------------------- الصفحات
@app.get("/")
def index():
    return send_from_directory(ROOT / "templates", "index.html")


@app.get("/img/<name>")
def img(name):
    if not re.fullmatch(r"[0-9a-f]{16}\.\w{2,5}", name):
        abort(404)
    return send_from_directory(IMG, name)


@app.get("/reports/<path:p>")
def reports(p):
    return send_from_directory(REPORTS, p)


# ---------------------------------------------------------------- الإعدادات والمدربون
@app.get("/api/state")
def api_state():
    sems = sorted(x.stem.replace("semester_", "") for x in (ROOT / "data").glob("semester_*.json"))
    return jsonify({"config": cfg(), "trainers": trainers(), "today": today().isoformat(),
                    "hijri_today": comms.hijri(today()), "semesters": sems})


@app.post("/api/config")
def api_config():
    c = cfg()
    for k in DEFAULT_CFG:
        if k in request.json:
            c[k] = str(request.json[k]).strip()
    _save("config.json", c)
    return jsonify({"ok": True, "config": c})


@app.post("/api/trainers")
def api_trainer_save():
    j = request.json or {}
    with LOCK:
        ts = trainers()
        tid = j.get("id") or uuid.uuid4().hex[:10]
        t = next((x for x in ts if x["id"] == tid), None)
        if t is None:
            t = {"id": tid, "mode": "path"}
            ts.append(t)
        for k in ("name", "email", "number", "path", "mode"):
            if k in j:
                t[k] = str(j[k]).strip().strip('"')
        if not t.get("name"):
            return jsonify({"ok": False, "error": "اكتب اسم المدرب."}), 400
        key = re.sub(r"\s+", "", t["name"])
        if any(x is not t and re.sub(r"\s+", "", x["name"]) == key for x in ts):
            return jsonify({"ok": False, "error": "يوجد مدرب بالاسم نفسه؛ الأسماء تُستخدم لربط الملفات فلا تُكرَّر."}), 400
        _save("trainers.json", ts)
    return jsonify({"ok": True, "trainer": t})


@app.delete("/api/trainers/<tid>")
def api_trainer_del(tid):
    with LOCK:
        ts = [x for x in trainers() if x["id"] != tid]
        _save("trainers.json", ts)
    up = UPLOADS / f"{tid}.xlsx"
    if up.exists():
        up.unlink()
    return jsonify({"ok": True})


@app.post("/api/trainers/order")
def api_trainer_order():
    ids = request.json.get("ids") or []
    with LOCK:
        ts = trainers()
        ts.sort(key=lambda x: ids.index(x["id"]) if x["id"] in ids else 999)
        _save("trainers.json", ts)
    return jsonify({"ok": True})


def _dialog(kind, initial=""):
    """نافذة اختيار ملف/مجلد من ويندوز (الخادم يعمل على جهاز المستخدم نفسه)."""
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    try:
        if kind == "folder":
            p = filedialog.askdirectory(title="اختر المجلد", initialdir=initial or None)
        else:
            p = filedialog.askopenfilename(title="اختر ملف متابعة المدرب", initialdir=initial or None,
                                           filetypes=[("Excel", "*.xlsx"), ("الكل", "*.*")])
    finally:
        root.destroy()
    return os.path.normpath(p) if p else ""


@app.post("/api/browse")
def api_browse():
    kind = (request.json or {}).get("kind", "file")
    init = (request.json or {}).get("initial", "")
    if init and os.path.isfile(init):
        init = os.path.dirname(init)
    try:
        return jsonify({"ok": True, "path": _dialog(kind, init)})
    except Exception as ex:
        return jsonify({"ok": False, "error": f"تعذر فتح نافذة الاختيار: {ex}"})


@app.post("/api/check")
def api_check():
    """يتحقق من ملف قبل ربطه: هل هو من القالب؟ ومن صاحبه؟"""
    p = (request.json or {}).get("path", "").strip().strip('"')
    if not os.path.isfile(p):
        return jsonify({"ok": False, "error": "الملف غير موجود."})
    try:
        raw = reader.read_workbook(p)
        return jsonify({"ok": True, "name": raw["info"]["name"], "dept": raw["info"]["dept"]})
    except reader.TemplateError as ex:
        return jsonify({"ok": False, "error": str(ex)})
    except Exception as ex:
        return jsonify({"ok": False, "error": f"تعذرت القراءة: {ex.__class__.__name__}"})


@app.post("/api/upload")
def api_upload():
    """سحب وإفلات: تُحفظ نسخة، وتُربط بالمدرب المحدد أو بمن يطابق اسمه داخل الملف (أو يُنشأ مدرب جديد)."""
    f = request.files.get("file")
    if not f:
        return jsonify({"ok": False, "error": "لم يصل ملف."}), 400
    UPLOADS.mkdir(parents=True, exist_ok=True)
    tmp = UPLOADS / f"_in_{uuid.uuid4().hex[:8]}.xlsx"
    f.save(tmp)
    try:
        raw = reader.read_workbook(tmp)
    except Exception as ex:
        tmp.unlink(missing_ok=True)
        msg = str(ex) if isinstance(ex, reader.TemplateError) else "تعذرت قراءة الملف."
        return jsonify({"ok": False, "error": f"{f.filename}: {msg}"})
    fname = raw["info"]["name"]
    tid = request.form.get("trainer") or ""
    with LOCK:
        ts = trainers()
        t = next((x for x in ts if x["id"] == tid), None)
        if t is None and fname:
            key = re.sub(r"\s+|^(م|أ|د)\.?\s*", "", fname)
            t = next((x for x in ts if re.sub(r"\s+|^(م|أ|د)\.?\s*", "", x["name"]) == key), None)
        created = False
        if t is None:
            t = {"id": uuid.uuid4().hex[:10], "name": fname or Path(f.filename).stem, "mode": "upload"}
            ts.append(t)
            created = True
        t["mode"] = "upload"
        t["uploaded"] = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
        t["upload_name"] = f.filename
        os.replace(tmp, UPLOADS / f"{t['id']}.xlsx")
        _save("trainers.json", ts)
    return jsonify({"ok": True, "trainer": t, "created": created, "file_name": fname})


@app.post("/api/scan")
def api_scan():
    """يبحث في مجلد (وما تحته حتى 6 مستويات) عن ملفات القالب ويعرض اسم صاحب كل ملف."""
    root = (request.json or {}).get("folder", "").strip().strip('"')
    if not os.path.isdir(root):
        return jsonify({"ok": False, "error": "المجلد غير موجود."})
    found, seen = [], 0
    base = root.rstrip("\\/").count(os.sep)
    for d, subs, files in os.walk(root):
        if d.count(os.sep) - base >= 6:
            subs[:] = []
        for fn in files:
            if not fn.lower().endswith(".xlsx") or fn.startswith("~$"):
                continue
            seen += 1
            if seen > 400:
                break
            p = os.path.join(d, fn)
            try:
                import zipfile
                with zipfile.ZipFile(p) as z:
                    wbx = z.read("xl/workbook.xml").decode("utf-8", "ignore")
                if "التقويم" not in wbx or "الملخص" not in wbx:
                    continue
                raw = reader.read_workbook(p)
                found.append({"path": p, "name": raw["info"]["name"], "dept": raw["info"]["dept"]})
            except Exception:
                continue
    linked = {os.path.normcase(file_of(t)) for t in trainers()}
    for x in found:
        x["linked"] = os.path.normcase(x["path"]) in linked
    return jsonify({"ok": True, "found": found})


@app.post("/api/create-file")
def api_create_file():
    """ينشئ ملف المتابعة (من القالب) لمدرب داخل مجلده، دون الكتابة فوق ملف موجود."""
    j = request.json or {}
    t = next((x for x in trainers() if x["id"] == j.get("id")), None)
    folder = (j.get("folder") or "").strip().strip('"')
    if not t:
        return jsonify({"ok": False, "error": "المدرب غير موجود."})
    if not os.path.isdir(folder):
        return jsonify({"ok": False, "error": "المجلد غير موجود."})
    c = cfg()
    out = Path(folder) / f"متابعة مهام - {_safe(t['name'])}.xlsx"
    if out.exists():
        return jsonify({"ok": False, "error": f"يوجد ملف بالاسم نفسه في المجلد: {out.name}"})
    try:
        build_template(out, name=t["name"], dept=c.get("dept", ""), number=t.get("number", ""),
                       unit=c.get("college", ""), sem_id=c.get("semester") or "1448_1")
    except Exception as ex:
        return jsonify({"ok": False, "error": f"تعذر إنشاء الملف: {ex}"})
    with LOCK:
        ts = trainers()
        for x in ts:
            if x["id"] == t["id"]:
                x["path"], x["mode"] = str(out), "path"
        _save("trainers.json", ts)
    return jsonify({"ok": True, "path": str(out)})


@app.post("/api/open")
def api_open():
    """يفتح ملف المدرب في Excel أو مجلده في المستكشف (على هذا الجهاز)."""
    j = request.json or {}
    t = next((x for x in trainers() if x["id"] == j.get("id")), None)
    p = file_of(t) if t else ""
    if not p or not os.path.exists(p):
        return jsonify({"ok": False, "error": "الملف غير موجود."})
    try:
        os.startfile(os.path.dirname(p) if j.get("what") == "folder" else p)
    except Exception as ex:
        return jsonify({"ok": False, "error": str(ex)})
    return jsonify({"ok": True})


# ---------------------------------------------------------------- المؤشرات
def _all_results():
    out = []
    for t in trainers():
        res, err = load_result(t)
        out.append((t, res, err))
    return out


@app.get("/api/dashboard")
def api_dashboard():
    rows = _all_results()
    items = [summary_of(t, r, e) for t, r, e in rows]
    ok = [r for _, r, _ in rows if r]
    weeks = []
    if ok:
        weeks = [{"n": w["n"], "title": w["title"], "started": w["started"], "note": w.get("note", ""),
                  "from": w["days"][0]["label"], "to": w["days"][-1]["label"]} for w in ok[0]["weeks"]]
    cur = ok[0]["current_week"] if ok else None
    return jsonify(_jsonable({"trainers": items, "weeks": weeks, "current_week": cur, "today": today(),
                              "hijri_today": comms.hijri(today())}))


@app.get("/api/trainer/<tid>")
def api_trainer(tid):
    t = next((x for x in trainers() if x["id"] == tid), None)
    if not t:
        abort(404)
    res, err = load_result(t)
    out = summary_of(t, res, err)
    if res:
        out["info"] = res["info"]
        out["detail_weeks"] = [{
            "n": w["n"], "title": w["title"], "note": w.get("note", ""), "started": w["started"],
            "from": w["days"][0]["label"], "to": w["days"][-1]["label"], "kpi": w["kpi"],
            "tasks": [_task_view(x) for x in w["tasks"]],
            "carried": [_task_view(x) for x in res["tasks"] if f"{x['id']}@{x['week']}" in set(w.get("carried") or [])],
        } for w in res["weeks"]]
        out["current_week"] = res["current_week"]
        out["lists"] = {k: [_task_view(x) for x in res[k]] for k in ("overdue", "no_evidence", "no_date", "pending_approval")}
    return jsonify(_jsonable(out))


@app.get("/api/messages")
def api_messages():
    week = request.args.get("week", type=int)
    rows = _all_results()
    results = [(t, r) for t, r, _ in rows]
    if week is None:
        week = next((r["current_week"] for _, r in results if r), 1)
    return jsonify({"week": week, "messages": comms.messages(cfg(), results, week)})


# ---------------------------------------------------------------- التقارير
def _safe(s):
    return re.sub(r'[\\/:*?"<>|]+', "-", s).strip()


@app.post("/api/report")
def api_report():
    j = request.json or {}
    kind = j.get("kind")
    week = j.get("week")
    c = cfg()
    stamp = today().isoformat()
    jobs = []  # (html_text, rel_path)
    rows = _all_results()
    if kind == "dept-week":
        html = comms.dept_week_html(c, [(t, r) for t, r, _ in rows], int(week))
        jobs.append((html, f"{stamp}/تقرير القسم - الأسبوع {week}"))
    elif kind in ("trainer-week", "trainer-semester", "all-week"):
        ids = [j.get("trainer")] if kind != "all-week" else [t["id"] for t, r, _ in rows if r]
        for t, r, err in rows:
            if t["id"] not in ids:
                continue
            if not r:
                return jsonify({"ok": False, "error": f"{t['name']}: {err}"})
            nm = _safe(short_name(t["name"]))
            if kind == "trainer-semester":
                jobs.append((comms.trainer_semester_html(c, t, r), f"{stamp}/{nm} - تقرير الفصل"))
            else:
                jobs.append((comms.trainer_week_html(c, t, r, int(week)), f"{stamp}/{nm} - الأسبوع {week}"))
    else:
        return jsonify({"ok": False, "error": "نوع تقرير غير معروف."}), 400
    made = []
    for html, rel in jobs:
        hp = REPORTS / (rel + ".html")
        hp.parent.mkdir(parents=True, exist_ok=True)
        hp.write_text(html, encoding="utf-8")
        made.append({"html": rel + ".html", "pdf": None})
    if j.get("pdf"):
        for m in made:
            pdf = REPORTS / m["html"].replace(".html", ".pdf")
            if print_pdf(str(REPORTS / m["html"]), str(pdf)):
                m["pdf"] = m["html"].replace(".html", ".pdf")
    return jsonify({"ok": True, "files": made})


@app.get("/api/reports")
def api_reports_list():
    out = []
    if REPORTS.exists():
        for p in sorted(REPORTS.rglob("*.html"), key=lambda x: x.stat().st_mtime, reverse=True)[:80]:
            rel = p.relative_to(REPORTS).as_posix()
            pdf = p.with_suffix(".pdf")
            out.append({"html": rel, "pdf": pdf.relative_to(REPORTS).as_posix() if pdf.exists() else None,
                        "time": dt.datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M")})
    return jsonify({"files": out})


# ---------------------------------------------------------------- إصدار ملفات المدربين وقفلها
ISSUED = DATA / "issued"


def _stamp():
    return dt.datetime.now().strftime("%Y-%m-%d %H%M%S")


def _zip_dir(folder, zpath):
    import zipfile
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(Path(folder).iterdir()):
            z.write(p, p.name)


def _copy_out(files, folder, sub):
    """نسخة من الملفات في مجلد يختاره المستخدم (البرنامج على الجهاز فقط)."""
    if not folder:
        return None
    if not os.path.isdir(folder):
        raise ValueError("مجلد الحفظ غير موجود.")
    dest = Path(folder) / sub
    clash = [f.name for f in files if (dest / f.name).exists()]
    if clash:   # يُفحص الكل قبل أي كتابة حتى لا يبقى إصدار ناقص في المجلد
        raise ValueError("يوجد في المجلد ملف بالاسم نفسه: " + "، ".join(clash))
    dest.mkdir(parents=True, exist_ok=True)
    out = []
    for f in files:
        target = dest / f.name
        target.write_bytes(f.read_bytes())
        out.append(target)
    return dest, out


@app.post("/api/issue")
def api_issue():
    """إصدار ملف متابعة لكل مدرب من القالب (معبأ بمهام القسم أو مفرغ)، مع رقم سري اختياري."""
    j = request.json or {}
    c = cfg()
    names = [n.strip() for n in (j.get("names") or []) if str(n).strip()]
    ids = j.get("ids") or []
    ts = trainers()
    chosen = [t for t in ts if t["id"] in ids]
    known = {re.sub(r"\s+", "", t["name"]) for t in chosen}
    extra = []
    for n in names:   # بلا تكرار: الاسم الثاني كان يكتب فوق ملف الأول
        k = re.sub(r"\s+", "", n)
        if k not in known:
            known.add(k)
            extra.append(n)
    if not chosen and not extra:
        return jsonify({"ok": False, "error": "اختر مدرباً واحداً على الأقل أو اكتب الأسماء."})
    pw = str(j.get("password") or "")
    blank = j.get("kind") == "blank"
    stamp = _stamp()
    work = ISSUED / f"إصدار {stamp}"
    work.mkdir(parents=True, exist_ok=True)
    people = [(t["name"], t.get("number", ""), t["id"]) for t in chosen] + [(n, "", None) for n in extra]
    made = []
    for name, number, tid in people:
        p = work / f"متابعة مهام - {_safe(name)}.xlsx"
        build_template(p, name=name, dept=c.get("dept", ""), number=number, unit=c.get("college", ""),
                       sem_id=c.get("semester") or "1448_1", blank=blank, password=pw)
        made.append((p, name, tid))
    zp = ISSUED / f"إصدار {stamp}.zip"
    _zip_dir(work, zp)
    res = {"ok": True, "zip": f"/issued/{zp.name}", "files": [p.name for p, _, _ in made], "count": len(made)}
    # اختياري (على الجهاز): نسخة في مجلد، وإضافة الأسماء الجديدة، وربط كل مدرب بملفه الجديد
    try:
        out = _copy_out([p for p, _, _ in made], (j.get("folder") or "").strip().strip('"'), f"إصدار ملفات المتابعة {stamp[:10]}")
    except ValueError as ex:
        return jsonify({"ok": False, "error": str(ex)})
    with LOCK:
        ts = trainers()
        if j.get("add_new", True):
            for _, name, tid in made:
                if tid is None and not any(re.sub(r"\s+", "", x["name"]) == re.sub(r"\s+", "", name) for x in ts):
                    ts.append({"id": uuid.uuid4().hex[:10], "name": name, "mode": "path", "path": ""})
        if out:
            dest, files = out
            res["folder"] = str(dest)
            if j.get("link"):
                by = {re.sub(r"\s+", "", name): f for (_, name, _), f in zip(made, files)}
                for x in ts:
                    f = by.get(re.sub(r"\s+", "", x["name"]))
                    if f:
                        x["path"], x["mode"] = str(f), "path"
        _save("trainers.json", ts)
    return jsonify(res)


@app.post("/api/lock")
def api_lock():
    """نسخة مقفلة من ملف كل مدرب مختار: كل الأوراق بالرقم السري، والأسابيع المختارة مقفلة كاملة."""
    import lock
    j = request.json or {}
    ids = j.get("ids") or []
    weeks = [int(w) for w in (j.get("weeks") or [])]
    pw = str(j.get("password") or "")
    if not pw:
        return jsonify({"ok": False, "error": "اكتب الرقم السري للقفل."})
    stamp = _stamp()
    work = ISSUED / f"قفل {stamp}"
    work.mkdir(parents=True, exist_ok=True)
    made, skipped = [], []
    suffix = (" - مقفل " + ("حتى الأسبوع " + str(max(weeks)) if weeks else "بالرقم السري"))
    for t in trainers():
        if t["id"] not in ids:
            continue
        p = file_of(t)
        if not p or not os.path.exists(p):
            skipped.append(f"{t['name']}: الملف غير موجود")
            continue
        try:
            data, _ = lock.lock_bytes(Path(p).read_bytes(), pw, weeks)
        except Exception as ex:
            skipped.append(f"{t['name']}: تعذر القفل ({ex.__class__.__name__})")
            continue
        out = work / f"متابعة مهام - {_safe(t['name'])}{suffix}.xlsx"
        out.write_bytes(data)
        made.append((out, t))
    if not made:
        return jsonify({"ok": False, "error": "لم يُقفل أي ملف. " + "، ".join(skipped)})
    zp = ISSUED / f"قفل {stamp}.zip"
    _zip_dir(work, zp)
    res = {"ok": True, "zip": f"/issued/{zp.name}", "files": [o.name for o, _ in made], "skipped": skipped}
    # على الجهاز: حفظ النسخة المقفلة بجانب ملف كل مدرب (الأصل لا يُعدَّل)
    if j.get("beside"):
        placed = []
        for o, t in made:
            src = file_of(t)
            if t.get("mode") == "upload" or not src:
                continue
            target = Path(src).with_name(Path(src).stem + suffix + ".xlsx")
            if target.exists():
                skipped.append(f"{t['name']}: يوجد ملف مقفل بالاسم نفسه")
                continue
            target.write_bytes(o.read_bytes())
            placed.append(str(target))
        res["placed"] = placed
    return jsonify(res)


@app.get("/issued/<path:p>")
def issued(p):
    return send_from_directory(ISSUED, p, as_attachment=True)


@app.get("/api/template")
def api_template_dl():
    """تنزيل قالب (معبأ أو مفرغ) بلا اسم مدرب — لمن يريد توزيعه بنفسه."""
    c = cfg()
    blank = request.args.get("kind") == "blank"
    stamp = _stamp()
    p = ISSUED / f"قالب {stamp}" / ("قالب مفرغ لمتابعة مهام عضو هيئة التدريب.xlsx" if blank else "قالب متابعة مهام عضو هيئة التدريب.xlsx")
    p.parent.mkdir(parents=True, exist_ok=True)
    build_template(p, dept=c.get("dept", ""), unit=c.get("college", ""), sem_id=c.get("semester") or "1448_1", blank=blank)
    return send_from_directory(p.parent, p.name, as_attachment=True)


@app.get("/api/ping")
def ping():
    return jsonify({"ok": True, "app": "tasks-followup"})


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    for d in (DATA, UPLOADS, IMG, REPORTS):
        d.mkdir(parents=True, exist_ok=True)
    print(f"برنامج متابعة مهام أعضاء هيئة التدريب: http://127.0.0.1:{PORT}")
    app.run(host="127.0.0.1", port=PORT, debug=False, threaded=True)
