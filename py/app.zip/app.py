"""برنامج متابعة مهام أعضاء هيئة التدريب — خادم محلي (http://127.0.0.1:8824).

يقرأ ملفات المدربين من مساراتها (أو نسخة مرفوعة بالسحب والإفلات) ولا يكتب فيها أبداً،
ويعرض المؤشرات، ويجهّز رسائل البريد للنسخ، ويُصدر التقارير على الورق الرسمي.
"""
import datetime as dt
import json
import os
import re
import sys
import threading
import uuid
from pathlib import Path

from flask import Flask, abort, jsonify, request, send_from_directory

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

import comms  # noqa: E402
import reader  # noqa: E402
import semester  # noqa: E402
from build_template import build as build_template  # noqa: E402
from letter_pdf import print_pdf  # noqa: E402
from names import short_name, honor_code, honor_from_name  # noqa: E402

DATA = Path(os.environ.get("TASKS_DATA") or ROOT / "data")
UPLOADS = DATA / "uploads"
IMG = DATA / "cache" / "img"
REPORTS = DATA / "reports"
PORT = int(os.environ.get("TASKS_PORT", "8824"))

app = Flask(__name__, static_folder=str(ROOT / "static"), static_url_path="/static")
app.json.ensure_ascii = False
LOCK = threading.Lock()
_cache = {}  # path -> (mtime, raw)

DEFAULT_CFG = {"dept": "", "college": "الكلية التقنية بحقل", "head_name": "", "semester": "1448_1", "today": ""}


# ---------------------------------------------------------------- التخزين
def _load(name, default):
    p = DATA / name
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            pass
    return default


def _save(name, obj):
    DATA.mkdir(parents=True, exist_ok=True)
    p = DATA / name
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, p)


def cfg():
    c = dict(DEFAULT_CFG)
    c.update(_load("config.json", {}))
    return c


FILE_KEYS = ("path", "mode", "uploaded", "upload_name", "archived")
BASE_KEYS = ("id", "name", "email", "number", "honor")
LEGACY_SEM = "1448_1"    # ملفات ما قبل تعدد الفصول كانت للفصل الأول 1448


def active_sem():
    return cfg().get("semester") or LEGACY_SEM


def _raw_trainers():
    """التخزين: {id, name, email, number, files: {فصل: {path, mode, uploaded, upload_name, archived}}}."""
    out = []
    for t in _load("trainers.json", []):
        if "files" not in t:     # ترحيل الصيغة القديمة (ملف واحد) إلى الفصل الأول 1448
            f = {k: t.pop(k) for k in FILE_KEYS if k in t}
            t["files"] = {LEGACY_SEM: f} if (f.get("path") or f.get("mode") == "upload") else {}
        else:
            for k in FILE_KEYS:
                t.pop(k, None)
        out.append(t)
    return out


def trainers(sem=None):
    """المدربون كما يراهم فصل محدد (الافتراضي الفصل النشط): بيانات المدرب + ملفه في ذلك الفصل."""
    sem = sem or active_sem()
    out = []
    for t in _raw_trainers():
        f = (t.get("files") or {}).get(sem, {})
        flat = {k: t.get(k, "") for k in BASE_KEYS}
        flat.update({"mode": "path", "path": ""})
        flat.update(f)
        flat["semester"] = sem
        flat["semesters_with_files"] = sorted(t.get("files", {}).keys())
        out.append(flat)
    return out


def save_trainers(ts, sem=None):
    """يحفظ القائمة (بترتيبها) ويضع حقول الملف في الفصل المحدد دون المساس بملفات الفصول الأخرى."""
    sem = sem or active_sem()
    raw = {t["id"]: t for t in _raw_trainers()}
    out = []
    for t in ts:
        r = raw.get(t["id"]) or {"id": t["id"], "files": {}}
        for k in BASE_KEYS:
            if k in t:
                r[k] = t[k]
        f = dict(r.get("files", {}).get(sem, {}))
        for k in FILE_KEYS:
            if k in t:
                f[k] = t[k]
        if f.get("path") or f.get("mode") == "upload" or f.get("archived"):
            r.setdefault("files", {})[sem] = {k: v for k, v in f.items() if v not in (None, "")}
        else:
            r.setdefault("files", {}).pop(sem, None)
        out.append(r)
    _save("trainers.json", out)


def today():
    t = (cfg().get("today") or "").strip()
    try:
        return dt.date.fromisoformat(t) if t else dt.date.today()
    except ValueError:
        return dt.date.today()


ARCHIVE = DATA / "archive"


def upload_path(tid, sem=None):
    return UPLOADS / (sem or active_sem()) / f"{tid}.xlsx"


def file_of(tr):
    """ملف المدرب في فصل (tr مسطّح من trainers): نسخة الأرشيف ← النسخة المرفوعة ← المسار."""
    sem = tr.get("semester") or active_sem()
    if tr.get("archived"):
        return str(ARCHIVE / sem / f"{tr['id']}.xlsx")
    if tr.get("mode") == "upload":
        p = upload_path(tr["id"], sem)
        legacy = UPLOADS / f"{tr['id']}.xlsx"          # النسخ المرفوعة قبل تعدد الفصول
        if not p.exists() and sem == LEGACY_SEM and legacy.exists():
            return str(legacy)
        return str(p)
    return tr.get("path") or ""


def load_result(tr):
    """يرجع (res، خطأ). يُعاد استخدام القراءة ما لم يتغير الملف."""
    p = file_of(tr)
    if not p:
        return None, "لم يُحدَّد مسار الملف"
    if not os.path.exists(p):
        return None, "الملف غير موجود في المسار"
    try:
        m = os.path.getmtime(p)
        hit = _cache.get(p)
        if hit and hit[0] == m:
            raw = hit[1]
        else:
            raw = reader.read_workbook(p, img_dir=str(IMG))
            _cache[p] = (m, raw)
        # compute يعدّل القاموس؛ نعطيه نسخة جديدة كل مرة
        import copy
        return reader.compute(copy.deepcopy(raw), today()), None
    except reader.TemplateError as ex:
        return None, str(ex)
    except Exception as ex:  # ملف تالف أو مقفل
        return None, f"تعذرت قراءة الملف: {ex.__class__.__name__}"


def _jsonable(o):
    if isinstance(o, (dt.date, dt.datetime)):
        return o.isoformat()
    if isinstance(o, dict):
        return {k: _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_jsonable(v) for v in o]
    return o


def _task_view(t):
    keys = ["id", "week", "week_title", "sheet", "section", "kind", "title", "due", "carry", "eval", "status", "done",
            "evidence", "evidence_url", "approval", "head_ev", "head_ev_url", "override", "notes", "pics", "head_pics",
            "speed", "speed_auto", "overdue", "has_evidence", "approved_done", "pending_approval"]
    return {k: t.get(k) for k in keys}


def summary_of(tr, res, err):
    out = {"id": tr["id"], "name": tr["name"], "short": short_name(tr["name"]), "email": tr.get("email", ""),
           "honor": tr.get("honor", ""), "honor_auto": honor_from_name(tr["name"]), "honor_used": honor_code(tr),
           "mode": tr.get("mode", "path"), "path": file_of(tr), "error": err}
    if res:
        cur = res["current_week"]
        w = next((x for x in res["weeks"] if x["n"] == cur), None)
        out.update({
            "file_name": res["info"].get("name"), "mtime": dt.datetime.fromtimestamp(res["mtime"]).strftime("%Y-%m-%d %H:%M"),
            "weeks": [dict(x["kpi"], n=x["n"], title=x["title"], started=x["started"]) for x in res["weeks"]],
            "total": res["total"], "current": w["kpi"] if w else None,
            "overdue": len(res["overdue"]), "no_evidence": len(res["no_evidence"]),
            "pending_approval": len(res["pending_approval"]), "no_date": len(res["no_date"]),
        })
    return out


# ---------------------------------------------------------------- الصفحات
@app.get("/")
def index():
    return send_from_directory(ROOT / "templates", "index.html")


@app.get("/img/<name>")
def img(name):
    if not re.fullmatch(r"[0-9a-f]{16}\.\w{2,5}", name):
        abort(404)
    return send_from_directory(IMG, name)


@app.get("/reports/<path:p>")
def reports(p):
    return send_from_directory(REPORTS, p)


# ---------------------------------------------------------------- الإعدادات والمدربون
@app.get("/api/state")
def api_state():
    sems = [{"id": s["id"], "title": s.get("title", s["id"])} for s in semester.list_specs()]
    return jsonify({"config": cfg(), "trainers": trainers(), "today": today().isoformat(),
                    "hijri_today": comms.hijri(today()), "semesters": [x["id"] for x in sems], "semester_list": sems,
                    "active_semester": active_sem()})


@app.post("/api/config")
def api_config():
    c = cfg()
    for k in DEFAULT_CFG:
        if k in request.json:
            c[k] = str(request.json[k]).strip()
    _save("config.json", c)
    return jsonify({"ok": True, "config": c})


@app.post("/api/trainers")
def api_trainer_save():
    j = request.json or {}
    with LOCK:
        ts = trainers()
        tid = j.get("id") or uuid.uuid4().hex[:10]
        t = next((x for x in ts if x["id"] == tid), None)
        if t is None:
            t = {"id": tid, "mode": "path"}
            ts.append(t)
        for k in ("name", "email", "number", "path", "mode"):
            if k in j:
                t[k] = str(j[k]).strip().strip('"')
        if "honor" in j:     # "" = تلقائي من الاسم
            h = str(j["honor"] or "").strip()
            t["honor"] = h if h in ("أ", "م", "د") else ""
        if not t.get("name"):
            return jsonify({"ok": False, "error": "اكتب اسم المدرب."}), 400
        key = re.sub(r"\s+", "", t["name"])
        if any(x is not t and re.sub(r"\s+", "", x["name"]) == key for x in ts):
            return jsonify({"ok": False, "error": "يوجد مدرب بالاسم نفسه؛ الأسماء تُستخدم لربط الملفات فلا تُكرَّر."}), 400
        save_trainers(ts)
    return jsonify({"ok": True, "trainer": t})


@app.delete("/api/trainers/<tid>")
def api_trainer_del(tid):
    with LOCK:
        ts = [x for x in trainers() if x["id"] != tid]
        save_trainers(ts)
    for up in list(UPLOADS.glob(f"{tid}.xlsx")) + list(UPLOADS.glob(f"*/{tid}.xlsx")):
        up.unlink()
    return jsonify({"ok": True})


@app.post("/api/trainers/order")
def api_trainer_order():
    ids = request.json.get("ids") or []
    with LOCK:
        ts = trainers()
        ts.sort(key=lambda x: ids.index(x["id"]) if x["id"] in ids else 999)
        save_trainers(ts)
    return jsonify({"ok": True})


def _dialog(kind, initial=""):
    """نافذة اختيار ملف/مجلد من ويندوز (الخادم يعمل على جهاز المستخدم نفسه)."""
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    try:
        if kind == "folder":
            p = filedialog.askdirectory(title="اختر المجلد", initialdir=initial or None)
        else:
            p = filedialog.askopenfilename(title="اختر ملف متابعة المدرب", initialdir=initial or None,
                                           filetypes=[("Excel", "*.xlsx"), ("الكل", "*.*")])
    finally:
        root.destroy()
    return os.path.normpath(p) if p else ""


@app.post("/api/browse")
def api_browse():
    kind = (request.json or {}).get("kind", "file")
    init = (request.json or {}).get("initial", "")
    if init and os.path.isfile(init):
        init = os.path.dirname(init)
    try:
        return jsonify({"ok": True, "path": _dialog(kind, init)})
    except Exception as ex:
        return jsonify({"ok": False, "error": f"تعذر فتح نافذة الاختيار: {ex}"})


@app.post("/api/check")
def api_check():
    """يتحقق من ملف قبل ربطه: هل هو من القالب؟ ومن صاحبه؟"""
    p = (request.json or {}).get("path", "").strip().strip('"')
    if not os.path.isfile(p):
        return jsonify({"ok": False, "error": "الملف غير موجود."})
    try:
        raw = reader.read_workbook(p)
        return jsonify({"ok": True, "name": raw["info"]["name"], "dept": raw["info"]["dept"]})
    except reader.TemplateError as ex:
        return jsonify({"ok": False, "error": str(ex)})
    except Exception as ex:
        return jsonify({"ok": False, "error": f"تعذرت القراءة: {ex.__class__.__name__}"})


@app.post("/api/upload")
def api_upload():
    """سحب وإفلات: تُحفظ نسخة، وتُربط بالمدرب المحدد أو بمن يطابق اسمه داخل الملف (أو يُنشأ مدرب جديد)."""
    f = request.files.get("file")
    if not f:
        return jsonify({"ok": False, "error": "لم يصل ملف."}), 400
    UPLOADS.mkdir(parents=True, exist_ok=True)
    tmp = UPLOADS / f"_in_{uuid.uuid4().hex[:8]}.xlsx"
    f.save(tmp)
    try:
        raw = reader.read_workbook(tmp)
    except Exception as ex:
        tmp.unlink(missing_ok=True)
        msg = str(ex) if isinstance(ex, reader.TemplateError) else "تعذرت قراءة الملف."
        return jsonify({"ok": False, "error": f"{f.filename}: {msg}"})
    fname = raw["info"]["name"]
    tid = request.form.get("trainer") or ""
    with LOCK:
        ts = trainers()
        t = next((x for x in ts if x["id"] == tid), None)
        if t is None and fname:
            key = re.sub(r"\s+|^(م|أ|د)\.?\s*", "", fname)
            t = next((x for x in ts if re.sub(r"\s+|^(م|أ|د)\.?\s*", "", x["name"]) == key), None)
        created = False
        if t is None:
            t = {"id": uuid.uuid4().hex[:10], "name": fname or Path(f.filename).stem, "mode": "upload"}
            ts.append(t)
            created = True
        t["mode"] = "upload"
        t["uploaded"] = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
        t["upload_name"] = f.filename
        dest = upload_path(t["id"])
        dest.parent.mkdir(parents=True, exist_ok=True)
        os.replace(tmp, dest)
        t["archived"] = ""
        save_trainers(ts)
    return jsonify({"ok": True, "trainer": t, "created": created, "file_name": fname})


@app.post("/api/scan")
def api_scan():
    """يبحث في مجلد (وما تحته حتى 6 مستويات) عن ملفات القالب ويعرض اسم صاحب كل ملف."""
    root = (request.json or {}).get("folder", "").strip().strip('"')
    if not os.path.isdir(root):
        return jsonify({"ok": False, "error": "المجلد غير موجود."})
    found, seen = [], 0
    base = root.rstrip("\\/").count(os.sep)
    for d, subs, files in os.walk(root):
        if d.count(os.sep) - base >= 6:
            subs[:] = []
        for fn in files:
            if not fn.lower().endswith(".xlsx") or fn.startswith("~$"):
                continue
            seen += 1
            if seen > 400:
                break
            p = os.path.join(d, fn)
            try:
                import zipfile
                with zipfile.ZipFile(p) as z:
                    wbx = z.read("xl/workbook.xml").decode("utf-8", "ignore")
                if "التقويم" not in wbx or "الملخص" not in wbx:
                    continue
                raw = reader.read_workbook(p)
                found.append({"path": p, "name": raw["info"]["name"], "dept": raw["info"]["dept"]})
            except Exception:
                continue
    linked = {os.path.normcase(file_of(t)) for t in trainers()}
    for x in found:
        x["linked"] = os.path.normcase(x["path"]) in linked
    return jsonify({"ok": True, "found": found})


@app.post("/api/create-file")
def api_create_file():
    """ينشئ ملف المتابعة (من القالب) لمدرب داخل مجلده، دون الكتابة فوق ملف موجود."""
    j = request.json or {}
    t = next((x for x in trainers() if x["id"] == j.get("id")), None)
    folder = (j.get("folder") or "").strip().strip('"')
    if not t:
        return jsonify({"ok": False, "error": "المدرب غير موجود."})
    if not os.path.isdir(folder):
        return jsonify({"ok": False, "error": "المجلد غير موجود."})
    c = cfg()
    out = Path(folder) / f"متابعة مهام - {_safe(t['name'])}.xlsx"
    if out.exists():
        return jsonify({"ok": False, "error": f"يوجد ملف بالاسم نفسه في المجلد: {out.name}"})
    try:
        build_template(out, name=t["name"], dept=c.get("dept", ""), number=t.get("number", ""),
                       unit=c.get("college", ""), sem_id=c.get("semester") or "1448_1")
    except Exception as ex:
        return jsonify({"ok": False, "error": f"تعذر إنشاء الملف: {ex}"})
    with LOCK:
        ts = trainers()
        for x in ts:
            if x["id"] == t["id"]:
                x["path"], x["mode"] = str(out), "path"
        save_trainers(ts)
    return jsonify({"ok": True, "path": str(out)})


@app.post("/api/open")
def api_open():
    """يفتح ملف المدرب في Excel أو مجلده في المستكشف (على هذا الجهاز)."""
    j = request.json or {}
    t = next((x for x in trainers() if x["id"] == j.get("id")), None)
    p = file_of(t) if t else ""
    if not p or not os.path.exists(p):
        return jsonify({"ok": False, "error": "الملف غير موجود."})
    try:
        os.startfile(os.path.dirname(p) if j.get("what") == "folder" else p)
    except Exception as ex:
        return jsonify({"ok": False, "error": str(ex)})
    return jsonify({"ok": True})


# ---------------------------------------------------------------- المؤشرات
def _all_results():
    out = []
    for t in trainers():
        res, err = load_result(t)
        out.append((t, res, err))
    return out


@app.get("/api/dashboard")
def api_dashboard():
    rows = _all_results()
    items = [summary_of(t, r, e) for t, r, e in rows]
    ok = [r for _, r, _ in rows if r]
    weeks = []
    if ok:
        weeks = [{"n": w["n"], "title": w["title"], "started": w["started"], "note": w.get("note", ""),
                  "from": w["days"][0]["label"], "to": w["days"][-1]["label"]} for w in ok[0]["weeks"]]
    cur = ok[0]["current_week"] if ok else None
    return jsonify(_jsonable({"trainers": items, "weeks": weeks, "current_week": cur, "today": today(),
                              "hijri_today": comms.hijri(today())}))


@app.get("/api/trainer/<tid>")
def api_trainer(tid):
    t = next((x for x in trainers() if x["id"] == tid), None)
    if not t:
        abort(404)
    res, err = load_result(t)
    out = summary_of(t, res, err)
    if res:
        out["info"] = res["info"]
        out["detail_weeks"] = [{
            "n": w["n"], "title": w["title"], "note": w.get("note", ""), "started": w["started"],
            "from": w["days"][0]["label"], "to": w["days"][-1]["label"], "kpi": w["kpi"],
            "tasks": [_task_view(x) for x in w["tasks"]],
            "carried": [_task_view(x) for x in res["tasks"] if f"{x['id']}@{x['week']}" in set(w.get("carried") or [])],
        } for w in res["weeks"]]
        out["current_week"] = res["current_week"]
        out["lists"] = {k: [_task_view(x) for x in res[k]] for k in ("overdue", "no_evidence", "no_date", "pending_approval")}
    return jsonify(_jsonable(out))


@app.get("/api/messages")
def api_messages():
    week = request.args.get("week", type=int)
    rows = _all_results()
    results = [(t, r) for t, r, _ in rows]
    if week is None:
        week = next((r["current_week"] for _, r in results if r), 1)
    return jsonify({"week": week, "messages": comms.messages(cfg(), results, week)})


# ---------------------------------------------------------------- التقارير
def _safe(s):
    return re.sub(r'[\\/:*?"<>|]+', "-", s).strip()


@app.post("/api/report")
def api_report():
    j = request.json or {}
    kind = j.get("kind")
    week = j.get("week")
    c = cfg()
    stamp = today().isoformat()
    jobs = []  # (html_text, rel_path)
    rows = _all_results()
    if kind == "dept-week":
        html = comms.dept_week_html(c, [(t, r) for t, r, _ in rows], int(week))
        jobs.append((html, f"{stamp}/تقرير القسم - الأسبوع {week}"))
    elif kind in ("trainer-week", "trainer-semester", "all-week"):
        ids = [j.get("trainer")] if kind != "all-week" else [t["id"] for t, r, _ in rows if r]
        for t, r, err in rows:
            if t["id"] not in ids:
                continue
            if not r:
                return jsonify({"ok": False, "error": f"{t['name']}: {err}"})
            nm = _safe(short_name(t["name"]))
            if kind == "trainer-semester":
                jobs.append((comms.trainer_semester_html(c, t, r), f"{stamp}/{nm} - تقرير الفصل"))
            else:
                jobs.append((comms.trainer_week_html(c, t, r, int(week)), f"{stamp}/{nm} - الأسبوع {week}"))
    else:
        return jsonify({"ok": False, "error": "نوع تقرير غير معروف."}), 400
    made = []
    for html, rel in jobs:
        hp = REPORTS / (rel + ".html")
        hp.parent.mkdir(parents=True, exist_ok=True)
        hp.write_text(html, encoding="utf-8")
        made.append({"html": rel + ".html", "pdf": None})
    if j.get("pdf"):
        for m in made:
            pdf = REPORTS / m["html"].replace(".html", ".pdf")
            if print_pdf(str(REPORTS / m["html"]), str(pdf)):
                m["pdf"] = m["html"].replace(".html", ".pdf")
    return jsonify({"ok": True, "files": made})


@app.get("/api/reports")
def api_reports_list():
    out = []
    if REPORTS.exists():
        for p in sorted(REPORTS.rglob("*.html"), key=lambda x: x.stat().st_mtime, reverse=True)[:80]:
            rel = p.relative_to(REPORTS).as_posix()
            pdf = p.with_suffix(".pdf")
            out.append({"html": rel, "pdf": pdf.relative_to(REPORTS).as_posix() if pdf.exists() else None,
                        "time": dt.datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M")})
    return jsonify({"files": out})


# ---------------------------------------------------------------- إصدار ملفات المدربين وقفلها
ISSUED = DATA / "issued"


def _stamp():
    return dt.datetime.now().strftime("%Y-%m-%d %H%M%S")


def _zip_dir(folder, zpath):
    import zipfile
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(Path(folder).iterdir()):
            z.write(p, p.name)


def _copy_out(files, folder, sub):
    """نسخة من الملفات في مجلد يختاره المستخدم (البرنامج على الجهاز فقط)."""
    if not folder:
        return None
    if not os.path.isdir(folder):
        raise ValueError("مجلد الحفظ غير موجود.")
    dest = Path(folder) / sub
    clash = [f.name for f in files if (dest / f.name).exists()]
    if clash:   # يُفحص الكل قبل أي كتابة حتى لا يبقى إصدار ناقص في المجلد
        raise ValueError("يوجد في المجلد ملف بالاسم نفسه: " + "، ".join(clash))
    dest.mkdir(parents=True, exist_ok=True)
    out = []
    for f in files:
        target = dest / f.name
        target.write_bytes(f.read_bytes())
        out.append(target)
    return dest, out


@app.post("/api/issue")
def api_issue():
    """إصدار ملف متابعة لكل مدرب من القالب (معبأ بمهام القسم أو مفرغ)، مع رقم سري اختياري."""
    j = request.json or {}
    c = cfg()
    names = [n.strip() for n in (j.get("names") or []) if str(n).strip()]
    ids = j.get("ids") or []
    ts = trainers()
    chosen = [t for t in ts if t["id"] in ids]
    known = {re.sub(r"\s+", "", t["name"]) for t in chosen}
    extra = []
    for n in names:   # بلا تكرار: الاسم الثاني كان يكتب فوق ملف الأول
        k = re.sub(r"\s+", "", n)
        if k not in known:
            known.add(k)
            extra.append(n)
    if not chosen and not extra:
        return jsonify({"ok": False, "error": "اختر مدرباً واحداً على الأقل أو اكتب الأسماء."})
    pw = str(j.get("password") or "")
    blank = j.get("kind") == "blank"
    stamp = _stamp()
    work = ISSUED / f"إصدار {stamp}"
    work.mkdir(parents=True, exist_ok=True)
    people = [(t["name"], t.get("number", ""), t["id"]) for t in chosen] + [(n, "", None) for n in extra]
    made = []
    for name, number, tid in people:
        p = work / f"متابعة مهام - {_safe(name)}.xlsx"
        build_template(p, name=name, dept=c.get("dept", ""), number=number, unit=c.get("college", ""),
                       sem_id=c.get("semester") or "1448_1", blank=blank, password=pw)
        made.append((p, name, tid))
    zp = ISSUED / f"إصدار {stamp}.zip"
    _zip_dir(work, zp)
    res = {"ok": True, "zip": f"/issued/{zp.name}", "files": [p.name for p, _, _ in made], "count": len(made)}
    # اختياري (على الجهاز): نسخة في مجلد، وإضافة الأسماء الجديدة، وربط كل مدرب بملفه الجديد
    try:
        out = _copy_out([p for p, _, _ in made], (j.get("folder") or "").strip().strip('"'), f"إصدار ملفات المتابعة {stamp[:10]}")
    except ValueError as ex:
        return jsonify({"ok": False, "error": str(ex)})
    with LOCK:
        ts = trainers()
        if j.get("add_new", True):
            for _, name, tid in made:
                if tid is None and not any(re.sub(r"\s+", "", x["name"]) == re.sub(r"\s+", "", name) for x in ts):
                    ts.append({"id": uuid.uuid4().hex[:10], "name": name, "mode": "path", "path": ""})
        if out:
            dest, files = out
            res["folder"] = str(dest)
            if j.get("link"):
                by = {re.sub(r"\s+", "", name): f for (_, name, _), f in zip(made, files)}
                for x in ts:
                    f = by.get(re.sub(r"\s+", "", x["name"]))
                    if f:
                        x["path"], x["mode"] = str(f), "path"
        save_trainers(ts)
    return jsonify(res)


@app.post("/api/lock")
def api_lock():
    """نسخة مقفلة من ملف كل مدرب مختار: كل الأوراق بالرقم السري، والأسابيع المختارة مقفلة كاملة."""
    import lock
    j = request.json or {}
    ids = j.get("ids") or []
    weeks = [int(w) for w in (j.get("weeks") or [])]
    pw = str(j.get("password") or "")
    if not pw:
        return jsonify({"ok": False, "error": "اكتب الرقم السري للقفل."})
    stamp = _stamp()
    work = ISSUED / f"قفل {stamp}"
    work.mkdir(parents=True, exist_ok=True)
    made, skipped = [], []
    suffix = (" - مقفل " + ("حتى الأسبوع " + str(max(weeks)) if weeks else "بالرقم السري"))
    for t in trainers():
        if t["id"] not in ids:
            continue
        p = file_of(t)
        if not p or not os.path.exists(p):
            skipped.append(f"{t['name']}: الملف غير موجود")
            continue
        try:
            data, _ = lock.lock_bytes(Path(p).read_bytes(), pw, weeks)
        except Exception as ex:
            skipped.append(f"{t['name']}: تعذر القفل ({ex.__class__.__name__})")
            continue
        out = work / f"متابعة مهام - {_safe(t['name'])}{suffix}.xlsx"
        out.write_bytes(data)
        made.append((out, t))
    if not made:
        return jsonify({"ok": False, "error": "لم يُقفل أي ملف. " + "، ".join(skipped)})
    zp = ISSUED / f"قفل {stamp}.zip"
    _zip_dir(work, zp)
    res = {"ok": True, "zip": f"/issued/{zp.name}", "files": [o.name for o, _ in made], "skipped": skipped}
    # على الجهاز: حفظ النسخة المقفلة بجانب ملف كل مدرب (الأصل لا يُعدَّل)
    if j.get("beside"):
        placed = []
        for o, t in made:
            src = file_of(t)
            if t.get("mode") == "upload" or not src:
                continue
            target = Path(src).with_name(Path(src).stem + suffix + ".xlsx")
            if target.exists():
                skipped.append(f"{t['name']}: يوجد ملف مقفل بالاسم نفسه")
                continue
            target.write_bytes(o.read_bytes())
            placed.append(str(target))
        res["placed"] = placed
    return jsonify(res)


@app.get("/issued/<path:p>")
def issued(p):
    return send_from_directory(ISSUED, p, as_attachment=True)


@app.get("/api/template")
def api_template_dl():
    """تنزيل قالب (معبأ أو مفرغ) بلا اسم مدرب — لمن يريد توزيعه بنفسه."""
    c = cfg()
    blank = request.args.get("kind") == "blank"
    stamp = _stamp()
    p = ISSUED / f"قالب {stamp}" / ("قالب مفرغ لمتابعة مهام عضو هيئة التدريب.xlsx" if blank else "قالب متابعة مهام عضو هيئة التدريب.xlsx")
    p.parent.mkdir(parents=True, exist_ok=True)
    build_template(p, dept=c.get("dept", ""), unit=c.get("college", ""), sem_id=c.get("semester") or "1448_1", blank=blank)
    return send_from_directory(p.parent, p.name, as_attachment=True)


# ---------------------------------------------------------------- الفصول التدريبية
def _sem_summary(spec):
    try:
        sem = semester.load_semester(spec)
        first, last = sem["weeks"][0]["days"][0], sem["weeks"][-1]["days"][-1]
        span = {"from": first["label"], "to": last["label"], "weeks": len([w for w in sem["weeks"] if w["n"] > 0]),
                "has_return": any(w["n"] == 0 for w in sem["weeks"]), "start": first["date"].isoformat(),
                "end": last["date"].isoformat()}
        err = None
    except Exception as ex:
        span, err = {}, str(ex)
    files = sum(1 for t in _raw_trainers() if spec["id"] in (t.get("files") or {}))
    archived = sum(1 for t in _raw_trainers() if (t.get("files") or {}).get(spec["id"], {}).get("archived"))
    return dict(span, id=spec["id"], title=spec.get("title", spec["id"]), term=spec.get("term", ""), year=spec.get("year", ""),
                active=spec["id"] == active_sem(), trainer_files=files, archived=archived, error=err)


@app.get("/api/semesters")
def api_semesters():
    return jsonify({"semesters": [_sem_summary(s) for s in semester.list_specs()], "active": active_sem(),
                    "terms": semester.TERMS, "max_weeks": semester.MAX_WEEKS})


@app.get("/api/semesters/<sid>")
def api_semester_get(sid):
    try:
        spec = semester.get_spec(sid)
    except KeyError as ex:
        return jsonify({"ok": False, "error": str(ex)}), 404
    sem = semester.load_semester(spec)
    return jsonify(_jsonable({"ok": True, "spec": spec, "weeks": semester.weeks_preview(sem), "summary": _sem_summary(spec)}))


@app.post("/api/semesters/preview")
def api_semester_preview():
    """يحسب الأسابيع من مواصفة دون حفظ — للمعاينة أثناء الكتابة."""
    try:
        spec = semester.clean_spec(request.json or {})
        sem = semester.load_semester(spec)
    except ValueError as ex:
        return jsonify({"ok": False, "error": str(ex)})
    return jsonify(_jsonable({"ok": True, "spec": spec, "weeks": semester.weeks_preview(sem)}))


@app.post("/api/semesters")
def api_semester_save():
    j = request.json or {}
    new = not j.get("id")
    try:
        spec = semester.clean_spec(j)
        if new and spec["id"] in {s["id"] for s in semester.list_specs()}:
            return jsonify({"ok": False, "error": f"يوجد فصل بالمعرّف نفسه ({spec['id']}). افتحه من القائمة لتعديله."})
        spec = semester.save_spec(spec)
    except ValueError as ex:
        return jsonify({"ok": False, "error": str(ex)})
    _cache.clear()
    return jsonify(_jsonable({"ok": True, "spec": spec, "weeks": semester.weeks_preview(semester.load_semester(spec))}))


@app.delete("/api/semesters/<sid>")
def api_semester_delete(sid):
    if sid == active_sem():
        return jsonify({"ok": False, "error": "لا يُحذف الفصل النشط؛ فعّل فصلاً آخر أولاً."})
    if any(sid in (t.get("files") or {}) for t in _raw_trainers()):
        return jsonify({"ok": False, "error": "للمدربين ملفات في هذا الفصل؛ لا يُحذف حتى لا تضيع متابعته."})
    semester.delete_spec(sid)
    return jsonify({"ok": True})


@app.post("/api/semesters/<sid>/activate")
def api_semester_activate(sid):
    try:
        semester.get_spec(sid)
    except KeyError as ex:
        return jsonify({"ok": False, "error": str(ex)})
    c = cfg()
    c["semester"] = sid
    _save("config.json", c)
    return jsonify({"ok": True, "active": sid})


@app.post("/api/semesters/<sid>/archive")
def api_semester_archive(sid):
    """أرشفة الفصل: نسخة ثابتة من ملف كل مدرب في البرنامج، فتبقى نتائجه وتقاريره ولو تغيّر الملف أو حُذف."""
    ts = trainers(sid)
    done, skipped = [], []
    for t in ts:
        if t.get("archived"):
            continue
        p = file_of(t)
        if not p or not os.path.exists(p):
            if p:
                skipped.append(f"{t['name']}: الملف غير موجود")
            continue
        dest = ARCHIVE / sid / f"{t['id']}.xlsx"
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(Path(p).read_bytes())
        t["archived"] = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
        done.append(t["name"])
    save_trainers(ts, sid)
    return jsonify({"ok": True, "archived": done, "skipped": skipped})


@app.get("/api/trainer/<tid>/history")
def api_trainer_history(tid):
    """نتائج المدرب في كل فصل له فيه ملف — للمقارنة بين الفصول."""
    rows = []
    for spec in semester.list_specs():
        t = next((x for x in trainers(spec["id"]) if x["id"] == tid), None)
        if not t or not (t.get("path") or t.get("mode") == "upload" or t.get("archived")):
            continue
        res, err = load_result(t)
        row = {"semester": spec["id"], "title": spec.get("title", spec["id"]), "archived": t.get("archived", ""), "error": err}
        if res:
            T = res["total"]
            row.update({"pct": T["pct"], "approved": T["approved"], "required": T["required"], "creative": T["creative"],
                        "overdue": len(res["overdue"]), "speed_share": T["speed_share"]})
        rows.append(row)
    return jsonify({"history": rows})


# ---------------------------------------------------------------- بنك المهام
@app.get("/api/bank")
def api_bank():
    b = semester.load_bank()
    return jsonify({"bank": b, "terms": semester.TERMS, "due_rules": list(semester.DUE_RULES),
                    "weekdays": ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس"]})


@app.post("/api/bank")
def api_bank_save():
    try:
        b = semester.save_bank(request.json or {})
    except ValueError as ex:
        return jsonify({"ok": False, "error": str(ex)})
    return jsonify({"ok": True, "bank": b})


@app.post("/api/bank/preview")
def api_bank_preview():
    """المهام الثابتة لكل أسبوع في فصل محدد من البنك المعروض (قبل الحفظ أو بعده)."""
    j = request.json or {}
    sid = j.get("semester") or active_sem()
    try:
        spec = semester.get_spec(sid)
        sem = semester.load_semester(spec)
        bank = semester.clean_bank(j["bank"]) if j.get("bank") else semester.load_bank()
    except (KeyError, ValueError) as ex:
        return jsonify({"ok": False, "error": str(ex)})
    old = semester.load_bank
    semester.load_bank = lambda: bank          # معاينة البنك غير المحفوظ
    try:
        tcfg = semester.load_tasks(spec)
    finally:
        semester.load_bank = old
    weeks = []
    for w in sem["weeks"]:
        items = []
        for t in semester.tasks_for_week(tcfg, w["n"]):
            due = semester.resolve_due(sem, w["n"], t["due"])
            items.append({"id": t["id"], "title": t["title"], "due": due["label"] if due else "مستمرة", "carry": t["carry"]})
        items += [{"id": "طارئة", "title": e["title"], "due": (semester.resolve_due(sem, w["n"], e["due"]) or {}).get("label", ""),
                   "carry": True, "emergency": True} for e in tcfg["emergency"] if int(e["week"]) == w["n"]]
        weeks.append({"n": w["n"], "title": w["title"], "tasks": items})
    return jsonify({"ok": True, "semester": spec.get("title", sid), "weeks": weeks})


@app.get("/api/bank/export")
def api_bank_export():
    b = semester.load_bank()
    data = json.dumps(b, ensure_ascii=False, indent=1).encode("utf-8")
    from flask import send_file
    import io
    return send_file(io.BytesIO(data), as_attachment=True, download_name=f"بنك المهام - {cfg().get('dept') or 'القسم'}.json",
                     mimetype="application/json")


@app.post("/api/bank/import")
def api_bank_import():
    f = request.files.get("file")
    if not f:
        return jsonify({"ok": False, "error": "اختر ملف بنك المهام (json)."})
    try:
        b = json.loads(f.read().decode("utf-8"))
        if not isinstance(b, dict) or "tasks" not in b:
            raise ValueError("الملف ليس بنك مهام من البرنامج.")
        b = semester.save_bank(b)
    except (ValueError, UnicodeDecodeError) as ex:
        return jsonify({"ok": False, "error": str(ex) if isinstance(ex, ValueError) and str(ex) else "الملف ليس بنك مهام صالحاً."})
    return jsonify({"ok": True, "tasks": len(b["tasks"])})


@app.get("/api/ping")
def ping():
    return jsonify({"ok": True, "app": "tasks-followup"})


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    for d in (DATA, UPLOADS, IMG, REPORTS):
        d.mkdir(parents=True, exist_ok=True)
    print(f"برنامج متابعة مهام أعضاء هيئة التدريب: http://127.0.0.1:{PORT}")
    app.run(host="127.0.0.1", port=PORT, debug=False, threaded=True)
