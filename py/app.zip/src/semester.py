"""تقويم الفصل: أيام العمل مرقّمة بالترتيب (تُستبعد الجمعة والسبت والإجازات)."""
import datetime as dt
import json
from pathlib import Path

from hijridate import Gregorian

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"

DAY_NAMES = {6: "الأحد", 0: "الاثنين", 1: "الثلاثاء", 2: "الأربعاء", 3: "الخميس", 4: "الجمعة", 5: "السبت"}
ORDINALS = ["", "الأول", "الثاني", "الثالث", "الرابع", "الخامس", "السادس", "السابع", "الثامن", "التاسع",
            "العاشر", "الحادي عشر", "الثاني عشر", "الثالث عشر", "الرابع عشر", "الخامس عشر",
            "السادس عشر", "السابع عشر", "الثامن عشر", "التاسع عشر", "العشرون"]


def hijri(d: dt.date) -> str:
    h = Gregorian(d.year, d.month, d.day).to_hijri()
    return f"{h.year}/{h.month:02d}/{h.day:02d}"


def week_title(n: int) -> str:
    return "أسبوع عودة أعضاء هيئة التدريب" if n == 0 else f"الأسبوع {ORDINALS[n]}"


def sheet_name(n: int) -> str:
    return "العودة" if n == 0 else f"أسبوع {n}"


def load_semester(sem_id: str = "1448_1") -> dict:
    sem = json.loads((DATA / f"semester_{sem_id}.json").read_text(encoding="utf-8"))
    off = {}
    for h in sem["holidays"]:
        if h["scope"] == "all" or (h["scope"] == "except_west" and sem.get("apply_except_west", True)):
            off[h["date"]] = h["name"]
    days, idx = [], 0
    for w in sem["weeks"]:
        start = dt.date.fromisoformat(w["start"])
        end = dt.date.fromisoformat(w["end"])
        w["title"] = week_title(w["n"])
        w["sheet"] = sheet_name(w["n"])
        w["days"], w["off"] = [], []
        d = start
        while d <= end:
            if d.weekday() in (4, 5):
                pass
            elif d.isoformat() in off:
                w["off"].append(f"{DAY_NAMES[d.weekday()]} {hijri(d)} ({off[d.isoformat()]})")
            else:
                idx += 1
                day = {"idx": idx, "date": d, "name": DAY_NAMES[d.weekday()], "hijri": hijri(d), "week": w["n"]}
                day["label"] = f"{day['name']} {day['hijri']}"
                days.append(day)
                w["days"].append(day)
            d += dt.timedelta(days=1)
    sem["days"] = days
    sem["by_n"] = {w["n"]: w for w in sem["weeks"]}
    return sem


def resolve_due(sem: dict, week_n: int, due: dict):
    """يرجع يوم الموعد (dict من days) أو None للمهام المستمرة."""
    rule = due.get("rule", "week_end")
    if rule == "ongoing":
        return None
    if rule == "week_end":
        return sem["by_n"][week_n + due.get("offset", 0)]["days"][-1]
    if rule == "week_end_of":
        return sem["by_n"][due["week"]]["days"][-1]
    if rule == "weekday":
        days = sem["by_n"][week_n]["days"]
        order = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس"]
        target = order.index(due["day"])
        before = [d for d in days if order.index(d["name"]) <= target]
        return before[-1] if before else days[0]
    raise ValueError(f"قاعدة موعد غير معروفة: {rule}")


def load_tasks(sem_id: str = "1448_1") -> dict:
    return json.loads((DATA / f"tasks_{sem_id}.json").read_text(encoding="utf-8"))


def tasks_for_week(cfg: dict, n: int) -> list:
    """weeks بعنصرين = مدى [من، إلى]، وغير ذلك = قائمة أسابيع."""
    out = []
    for t in cfg["tasks"]:
        w = t["weeks"]
        if (w[0] <= n <= w[1]) if len(w) == 2 else (n in w):
            out.append(t)
    return out
