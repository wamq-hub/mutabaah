"""الفصول التدريبية وبنك المهام.

- الفصل يُعرَّف بمواصفة مختصرة (بداية الأسبوع الأول، عدد الأسابيع، فترات الإجازة، الإجازات المفردة، ملاحظات)
  والبرنامج يحسب منها الأسابيع وأيام العمل المرقّمة (تُستبعد الجمعة والسبت والإجازات) والتواريخ الهجرية.
- الأسبوع الذي تقع أيامه كلها داخل فترة إجازة لا يُعدّ (مثل إجازة الخريف والأعياد).
- بنك المهام واحد للقسم ويتكرر كل فصل؛ والمهمة يمكن تخصيصها بفصل (الأول/الثاني/الصيفي).
- الفصول وبنك المهام محفوظة في مجلد بيانات المستخدم (TASKS_DATA)، وتُنسخ أول مرة من الافتراضيات المرفقة.
"""
import copy
import datetime as dt
import json
import os
import re
from pathlib import Path

from hijridate import Gregorian

ROOT = Path(__file__).resolve().parent.parent
DEFAULTS = ROOT / "data"                       # افتراضيات مرفقة مع البرنامج
DATA = DEFAULTS                                # للتوافق مع الاستيراد القديم


def user_dir() -> Path:
    return Path(os.environ.get("TASKS_DATA") or DEFAULTS)


DAY_NAMES = {6: "الأحد", 0: "الاثنين", 1: "الثلاثاء", 2: "الأربعاء", 3: "الخميس", 4: "الجمعة", 5: "السبت"}
ORDINALS = ["", "الأول", "الثاني", "الثالث", "الرابع", "الخامس", "السادس", "السابع", "الثامن", "التاسع",
            "العاشر", "الحادي عشر", "الثاني عشر", "الثالث عشر", "الرابع عشر", "الخامس عشر",
            "السادس عشر", "السابع عشر", "الثامن عشر", "التاسع عشر", "العشرون", "الحادي والعشرون",
            "الثاني والعشرون", "الثالث والعشرون", "الرابع والعشرون", "الخامس والعشرون"]
TERMS = ["الأول", "الثاني", "الصيفي"]
MAX_WEEKS = len(ORDINALS) - 1


def hijri(d: dt.date) -> str:
    h = Gregorian(d.year, d.month, d.day).to_hijri()
    return f"{h.year}/{h.month:02d}/{h.day:02d}"


def week_title(n: int) -> str:
    return "أسبوع عودة أعضاء هيئة التدريب" if n == 0 else f"الأسبوع {ORDINALS[n]}"


def sheet_name(n: int) -> str:
    return "العودة" if n == 0 else f"أسبوع {n}"


def _d(s):
    return s if isinstance(s, dt.date) else dt.date.fromisoformat(str(s)[:10])


# ---------------------------------------------------------------- تخزين الفصول
def _sem_dir() -> Path:
    d = user_dir() / "semesters"
    if not d.exists():
        d.mkdir(parents=True, exist_ok=True)
    # تُنسخ الفصول المرفقة التي لا توجد عند المستخدم (أول تشغيل، أو فصل جديد مرفق في تحديث)
    for p in DEFAULTS.glob("semester_*.json"):
        sid = p.stem.replace("semester_", "")
        target = d / f"{sid}.json"
        if not target.exists() and not (d / f"{sid}.deleted").exists():
            target.write_text(p.read_text(encoding="utf-8"), encoding="utf-8")
    return d


def list_specs() -> list:
    out = []
    for p in sorted(_sem_dir().glob("*.json")):
        try:
            s = json.loads(p.read_text(encoding="utf-8"))
            s["id"] = p.stem
            out.append(s)
        except (OSError, ValueError):
            continue
    out.sort(key=lambda s: s.get("week1_start") or s.get("weeks", [{}])[0].get("start", ""))
    return out


def get_spec(sem_id: str) -> dict:
    p = _sem_dir() / f"{sem_id}.json"
    if not p.exists():
        raise KeyError(f"الفصل غير موجود: {sem_id}")
    s = json.loads(p.read_text(encoding="utf-8"))
    s["id"] = sem_id
    return s


def save_spec(spec: dict) -> dict:
    spec = clean_spec(spec)
    load_semester(spec)       # يتحقق أن المواصفة تُنتج أسابيع صحيحة قبل الحفظ
    p = _sem_dir() / f"{spec['id']}.json"
    p.write_text(json.dumps(spec, ensure_ascii=False, indent=1), encoding="utf-8")
    tomb = _sem_dir() / f"{spec['id']}.deleted"
    if tomb.exists():
        tomb.unlink()
    return spec


def delete_spec(sem_id: str):
    d = _sem_dir()
    (d / f"{sem_id}.json").unlink(missing_ok=True)
    (d / f"{sem_id}.deleted").write_text("", encoding="utf-8")   # حتى لا يعود من الافتراضيات


def clean_spec(spec: dict) -> dict:
    """يتحقق من المواصفة ويوحّدها، ويرفع ValueError برسالة عربية."""
    s = {k: spec.get(k) for k in ("id", "title", "term", "year", "return_start", "week1_start", "weeks_count",
                                   "breaks", "holidays", "notes", "apply_except_west", "sources")}
    term = s["term"] or ""
    if term not in TERMS:
        raise ValueError("اختر الفصل: الأول أو الثاني أو الصيفي.")
    year = str(s["year"] or "").strip()
    if not re.fullmatch(r"1[45]\d\d", year):
        raise ValueError("اكتب العام التدريبي الهجري بأربعة أرقام، مثل 1448.")
    s["year"] = year
    if not s["id"]:
        s["id"] = f"{year}_{TERMS.index(term) + 1}"
    if not re.fullmatch(r"[0-9A-Za-z_-]{3,40}", s["id"]):
        raise ValueError("معرّف الفصل غير صالح.")
    s["title"] = (s["title"] or f"الفصل التدريبي {term} {year}هـ").strip()
    try:
        w1 = _d(s["week1_start"])
    except (TypeError, ValueError):
        raise ValueError("اختر تاريخ بداية الأسبوع الأول.")
    if w1.weekday() != 6:
        raise ValueError("بداية الأسبوع الأول يجب أن تكون يوم أحد.")
    s["week1_start"] = w1.isoformat()
    if s["return_start"]:
        r = _d(s["return_start"])
        if r.weekday() != 6 or r >= w1:
            raise ValueError("أسبوع العودة يبدأ يوم أحد قبل الأسبوع الأول.")
        s["return_start"] = r.isoformat()
    else:
        s["return_start"] = None
    try:
        n = int(s["weeks_count"])
    except (TypeError, ValueError):
        raise ValueError("اكتب عدد أسابيع الفصل.")
    if not 1 <= n <= MAX_WEEKS:
        raise ValueError(f"عدد الأسابيع بين 1 و{MAX_WEEKS}.")
    s["weeks_count"] = n
    br = []
    for b in s["breaks"] or []:
        if not b.get("from") or not b.get("to"):
            continue
        f, t = _d(b["from"]), _d(b["to"])
        if t < f:
            raise ValueError(f"فترة الإجازة «{b.get('name', '')}»: النهاية قبل البداية.")
        br.append({"from": f.isoformat(), "to": t.isoformat(), "name": (b.get("name") or "إجازة").strip()})
    s["breaks"] = br
    hs = []
    for h in s["holidays"] or []:
        if not h.get("date"):
            continue
        hs.append({"date": _d(h["date"]).isoformat(), "name": (h.get("name") or "إجازة").strip(),
                   "scope": h.get("scope") if h.get("scope") in ("all", "except_west") else "all"})
    s["holidays"] = sorted(hs, key=lambda x: x["date"])
    s["notes"] = {str(k): str(v).strip() for k, v in (s["notes"] or {}).items() if str(v).strip()}
    s["apply_except_west"] = bool(True if s["apply_except_west"] is None else s["apply_except_west"])
    s["sources"] = [str(x) for x in (s["sources"] or []) if str(x).strip()]
    return s


# ---------------------------------------------------------------- حساب الأسابيع
def _in_break(day, breaks):
    return next((b for b in breaks if _d(b["from"]) <= day <= _d(b["to"])), None)


def generate_weeks(spec: dict) -> list:
    """مواصفة الفصل ← قائمة أسابيع {n, start, end, note}. القديم (weeks صريحة) يمرّ كما هو."""
    if spec.get("weeks") and not spec.get("week1_start"):
        return [dict(w) for w in spec["weeks"]]
    breaks = spec.get("breaks") or []
    notes = spec.get("notes") or {}
    weeks = []
    if spec.get("return_start"):
        r = _d(spec["return_start"])
        weeks.append({"n": 0, "start": r.isoformat(), "end": (r + dt.timedelta(days=4)).isoformat(),
                      "note": notes.get("0", "عودة أعضاء هيئة التدريب قبل بداية التدريب")})
    d, n, prev_break, guard = _d(spec["week1_start"]), 1, None, 0
    while n <= int(spec["weeks_count"]):
        guard += 1
        if guard > 80:
            raise ValueError("فترات الإجازة تغطي الفصل كله تقريباً؛ راجع التواريخ.")
        days = [d + dt.timedelta(days=i) for i in range(5)]
        hits = [_in_break(x, breaks) for x in days]
        if all(hits):                        # الأسبوع كله إجازة: لا يُعدّ
            prev_break = hits[0]
            if weeks and not weeks[-1].get("_before"):
                weeks[-1]["_before"] = prev_break["name"]
            d += dt.timedelta(days=7)
            continue
        note = []
        if prev_break:
            note.append(f"العودة بعد {prev_break['name']}")
            prev_break = None
        weeks.append({"n": n, "start": d.isoformat(), "end": days[-1].isoformat(), "_note": note})
        n += 1
        d += dt.timedelta(days=7)
    for w in weeks:
        if w["n"] == 0:
            continue
        auto = list(w.pop("_note", []))
        if w.get("_before"):
            auto.append(f"تبدأ {w.pop('_before')} بعد نهاية الأسبوع")
        # أيام داخل فترة إجازة جزئية (مثل بداية العيد منتصف الأسبوع) تُعامل كإجازة
        custom = notes.get(str(w["n"]))
        w["note"] = "، ".join(([custom] if custom else []) + auto)
    return weeks


def _break_days(spec):
    out = {}
    for b in spec.get("breaks") or []:
        d, t = _d(b["from"]), _d(b["to"])
        while d <= t:
            out[d.isoformat()] = b["name"]
            d += dt.timedelta(days=1)
    return out


def load_semester(sem="1448_1") -> dict:
    """sem: معرّف فصل أو مواصفة ← الفصل بأسابيعه وأيام العمل المرقّمة."""
    spec = get_spec(sem) if isinstance(sem, str) else copy.deepcopy(sem)
    out = dict(spec)
    off = {}
    for h in spec.get("holidays") or []:
        if h.get("scope", "all") == "all" or (h.get("scope") == "except_west" and spec.get("apply_except_west", True)):
            off[h["date"]] = h["name"]
    for k, v in _break_days(spec).items():
        off.setdefault(k, v)
    weeks = generate_weeks(spec)
    days, idx = [], 0
    for w in weeks:
        start, end = _d(w["start"]), _d(w["end"])
        w["title"] = week_title(w["n"])
        w["sheet"] = sheet_name(w["n"])
        w["days"], w["off"] = [], []
        w.setdefault("note", "")
        d = start
        while d <= end:
            if d.weekday() in (4, 5):
                pass
            elif d.isoformat() in off:
                w["off"].append(f"{DAY_NAMES[d.weekday()]} {hijri(d)} ({off[d.isoformat()]})")
            else:
                idx += 1
                day = {"idx": idx, "date": d, "name": DAY_NAMES[d.weekday()], "hijri": hijri(d), "week": w["n"]}
                day["label"] = f"{day['name']} {day['hijri']}"
                days.append(day)
                w["days"].append(day)
            d += dt.timedelta(days=1)
        if not w["days"]:
            raise ValueError(f"{w['title']} بلا أيام عمل (كل أيامه إجازة)؛ راجع الإجازات.")
    out["weeks"] = weeks
    out["days"] = days
    out["by_n"] = {w["n"]: w for w in weeks}
    out.setdefault("title", "الفصل التدريبي")
    return out


def weeks_preview(sem: dict) -> list:
    """ملخص الأسابيع للواجهة."""
    return [{"n": w["n"], "title": w["title"], "from": w["days"][0]["label"], "to": w["days"][-1]["label"],
             "start": w["start"], "end": w["end"], "workdays": len(w["days"]), "off": w["off"], "note": w.get("note", "")}
            for w in sem["weeks"]]


def resolve_due(sem: dict, week_n: int, due: dict):
    """يرجع يوم الموعد (dict من days) أو None للمهام المستمرة. الأسبوع غير الموجود ← آخر أسبوع في الفصل."""
    rule = due.get("rule", "week_end")
    last = max(sem["by_n"])

    def week(n):
        return sem["by_n"].get(min(n, last)) or sem["by_n"][last]
    if rule == "ongoing":
        return None
    if rule == "week_end":
        return week(week_n + int(due.get("offset", 0) or 0))["days"][-1]
    if rule == "week_end_of":
        return week(int(due["week"]))["days"][-1]
    if rule == "weekday":
        days = week(week_n)["days"]
        order = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس"]
        target = order.index(due["day"])
        before = [d for d in days if order.index(d["name"]) <= target]
        return before[-1] if before else days[0]
    raise ValueError(f"قاعدة موعد غير معروفة: {rule}")


# ---------------------------------------------------------------- بنك المهام
def bank_path() -> Path:
    return user_dir() / "bank.json"


def _default_bank() -> dict:
    return json.loads((DEFAULTS / "bank_default.json").read_text(encoding="utf-8"))


def load_bank() -> dict:
    p = bank_path()
    if p.exists():
        b = json.loads(p.read_text(encoding="utf-8"))
        if "suggested" not in b:      # بنك حُفظ قبل إضافة المهام المقترحة: تُلحق من الافتراضي
            b["suggested"] = _default_bank().get("suggested", [])
        return b
    return _default_bank()


def save_bank(bank: dict) -> dict:
    bank = clean_bank(bank)
    p = bank_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(bank, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, p)
    return bank


DUE_RULES = ("week_end", "weekday", "week_end_of", "ongoing")


def clean_bank(bank: dict) -> dict:
    base = load_bank() if bank_path().exists() else json.loads((DEFAULTS / "bank_default.json").read_text(encoding="utf-8"))
    out = dict(base)
    for k in ("deadline_time", "speed", "emergency_rows", "emergency_spare_rows", "fixed_spare_rows", "blank_fixed_rows",
              "creative_rows", "creative_spare_rows", "carried_rows"):
        if k in bank:
            out[k] = bank[k]
    out["eval_items"] = base["eval_items"]          # بنود نموذج التقييم الرسمي ثابتة
    tasks, ids = [], set()
    for i, t in enumerate(bank.get("tasks") or [], 1):
        title = str(t.get("title") or "").strip()
        if not title:
            continue
        tid = str(t.get("id") or f"T{i}").strip()
        if not re.fullmatch(r"[0-9A-Za-z_-]{1,20}", tid) or tid in ids:
            tid = f"T{len(ids) + 1}"
            while tid in ids:
                tid += "x"
        ids.add(tid)
        w = [int(x) for x in (t.get("weeks") or []) if str(x).isdigit()]
        mode = "list" if t.get("weeks_mode") == "list" else "range"
        if not w or (mode == "range" and (len(w) != 2 or w[0] > w[1])):
            raise ValueError(f"المهمة «{title}»: حدّد الأسابيع (من، إلى) أو قائمة أسابيع.")
        if mode == "list":
            w = sorted(set(w))
        due = dict(t.get("due") or {"rule": "week_end"})
        if due.get("rule") not in DUE_RULES:
            raise ValueError(f"المهمة «{title}»: قاعدة الموعد غير معروفة.")
        terms = [x for x in (t.get("terms") or []) if x in TERMS]
        evals = [int(x) for x in (t.get("eval") or []) if str(x).isdigit() and 1 <= int(x) <= 20]
        item = {"id": tid, "title": title, "weeks": w, "weeks_mode": mode, "due": due, "carry": bool(t.get("carry")),
                "eval": evals, "why": str(t.get("why") or "").strip(), "terms": terms}
        for k in ("from_suggested", "source", "ref"):      # أصل المهمة إن أُضيفت من المقترحة
            if t.get(k):
                item[k] = str(t[k])
        tasks.append(item)
    out["tasks"] = tasks
    # المهام المقترحة (من المفكرة الإشرافية وتقويم أعمال الجودة): تُحفظ كما هي ولا تدخل ملفات المدربين
    sug = bank.get("suggested")
    out["suggested"] = sug if isinstance(sug, list) else base.get("suggested", [])
    out["emergency"] = [e for e in (bank.get("emergency", base.get("emergency")) or []) if e.get("title")]
    return out


def load_tasks(sem="1448_1") -> dict:
    """مهام بنك القسم المنطبقة على فصل محدد (حسب الفصل الأول/الثاني/الصيفي وعدد الأسابيع وأسبوع العودة)."""
    bank = load_bank()
    spec = get_spec(sem) if isinstance(sem, str) else sem
    sem_id = spec.get("id", "")
    term = spec.get("term", "")
    count = int(spec.get("weeks_count") or len([w for w in generate_weeks(spec) if w["n"] > 0]))
    has_return = bool(spec.get("return_start")) or any(w.get("n") == 0 for w in (spec.get("weeks") or []))
    cfg = dict(bank)
    tasks = []
    for t in bank.get("tasks", []):
        if t.get("terms") and term and term not in t["terms"]:
            continue
        w = list(t["weeks"])
        if is_range(t):
            lo, hi = w
            if lo == 0 and not has_return:
                lo = 1
            if lo > count:
                continue
            w = [lo, min(hi, count)]
        else:
            w = [x for x in w if (x == 0 and has_return) or 1 <= x <= count]
            if not w:
                continue
        tasks.append(dict(t, weeks=w))
    cfg["tasks"] = tasks
    cfg["emergency"] = [e for e in bank.get("emergency", []) if e.get("semester") == sem_id and 0 <= int(e["week"]) <= count]
    cfg["semester"] = sem_id
    return cfg


def is_range(t: dict) -> bool:
    """weeks مدى [من، إلى] ما لم تكن weeks_mode = list (قائمة أسابيع محددة)."""
    return t.get("weeks_mode", "range" if len(t["weeks"]) == 2 else "list") == "range"


def tasks_for_week(cfg: dict, n: int) -> list:
    out = []
    for t in cfg["tasks"]:
        w = t["weeks"]
        if (w[0] <= n <= w[1]) if is_range(t) else (n in w):
            out.append(t)
    return out
