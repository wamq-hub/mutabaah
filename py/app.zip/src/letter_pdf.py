# -*- coding: utf-8 -*-
"""طباعة خطاب الكليشة (HTML) إلى PDF بمتصفح Edge بلا واجهة — نفس زر «طباعة / حفظ PDF» في الخطاب.
التعديلات اليدوية التي يحفظها المستخدم في متصفحه لا تدخل هنا؛ هذه نسخة الإصدار كما وُلِّدت."""
import os
import pathlib
import shutil
import subprocess
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor

EDGE_PATHS = [r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
              r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"]


def edge_path():
    return next((p for p in EDGE_PATHS if os.path.exists(p)), None)


def print_pdf(html, pdf, timeout=60):
    """يرجع True إن ظهر ملف PDF. ملف تعريف مؤقت لكل طباعة، وانتظار الملف لأن مشغّل Edge ينفصل."""
    edge = edge_path()
    if not edge:
        return False
    if os.path.exists(pdf):
        os.remove(pdf)
    prof = tempfile.mkdtemp(prefix="edge-letter-")
    try:
        subprocess.Popen([edge, "--headless=new", "--edge-skip-compat-layer-relaunch", "--disable-gpu",
                          f"--user-data-dir={prof}", "--virtual-time-budget=8000", "--no-pdf-header-footer",
                          f"--print-to-pdf={pdf}", pathlib.Path(html).as_uri()],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        t0 = time.time()
        last = -1
        while time.time() - t0 < timeout:
            if os.path.exists(pdf):
                size = os.path.getsize(pdf)
                if size > 0 and size == last:      # ثبت الحجم = انتهت الكتابة
                    return True
                last = size
            time.sleep(0.7)
        return os.path.exists(pdf) and os.path.getsize(pdf) > 0
    finally:
        time.sleep(0.5)
        shutil.rmtree(prof, ignore_errors=True)


def print_many(pairs, workers=3):
    """pairs: [(html, pdf)] → {pdf: True/False}"""
    with ThreadPoolExecutor(max_workers=workers) as ex:
        res = list(ex.map(lambda hp: print_pdf(*hp), pairs))
    return {pdf: ok for (_, pdf), ok in zip(pairs, res)}
