"""قفل ملف متابعة المدرب برقم سري
(الأسبوع المقفل كاملاً: تُقفل خاناته المفتوحة نفسها أيضاً، لا منع التحديد وحده — فبعض تطبيقات Excel لا تلتزم بمنع التحديد) من رئيس القسم — يُكتب نسخة جديدة ولا يُعدَّل الملف الأصلي.

يعدّل XML داخل ملف xlsx مباشرة (sheetProtection وworkbookProtection) ولا يعيد حفظ الملف بـopenpyxl،
لأن Excel يحفظ القوائم المنسدلة المرتبطة بورقة أخرى كامتداد x14 تحذفه openpyxl عند إعادة الحفظ.

- كل الأوراق: الحماية نفسها (الخانات المفتوحة للتعبئة تبقى مفتوحة) مع الرقم السري.
- أسابيع تُقفل كاملة: لا يمكن تحديد أي خانة فيها ولا تعديلها ولا إدراج صور.
- هيكل المصنف: لا إضافة أوراق ولا حذفها ولا إظهار المخفي منها.
"""
import io
import re
import zipfile

from openpyxl.utils.protection import hash_password

NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
# الترتيب في مخطط الورقة: sheetProtection بعد sheetData وsheetCalcPr
_AFTER = [r"</sheetData>", r"<sheetData\s*/>"]


def _week_no(name):
    if name == "العودة":
        return 0
    m = re.fullmatch(r"أسبوع (\d+)", name)
    return int(m.group(1)) if m else None


def _sheet_map(z):
    """اسم الورقة ← مسار ملف XML داخل الحزمة."""
    wb = z.read("xl/workbook.xml").decode("utf-8")
    rels = z.read("xl/_rels/workbook.xml.rels").decode("utf-8")
    targets = {m.group(1): m.group(2) for m in re.finditer(r'<Relationship[^>]*\bId="([^"]+)"[^>]*\bTarget="([^"]+)"', rels)}
    targets.update({m.group(2): m.group(1) for m in re.finditer(r'<Relationship[^>]*\bTarget="([^"]+)"[^>]*\bId="([^"]+)"', rels)})
    out = {}
    for m in re.finditer(r"<sheet\b[^>]*>", wb):
        tag = m.group(0)
        name = re.search(r'\bname="([^"]*)"', tag).group(1)
        rid = re.search(r'\br:id="([^"]+)"', tag) or re.search(r'\bid="([^"]+)"', tag)
        t = targets.get(rid.group(1), "")
        t = t.lstrip("/")
        out[_unxml(name)] = t if t.startswith("xl/") else "xl/" + t
    return out


def _unxml(s):
    return s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"').replace("&apos;", "'")


def _protect_sheet(xml, pw_hash, full):
    old = re.search(r"<sheetProtection\b[^>]*/>", xml)
    attrs = {}
    if old:
        attrs = dict(re.findall(r'(\w+)="([^"]*)"', old.group(0)))
        xml = xml[:old.start()] + xml[old.end():]
    for k in ("algorithmName", "hashValue", "saltValue", "spinCount", "password"):
        attrs.pop(k, None)
    attrs["sheet"] = "1"
    if pw_hash:
        attrs["password"] = pw_hash
    if full:
        attrs.update({"objects": "1", "scenarios": "1", "selectLockedCells": "1", "selectUnlockedCells": "1",
                      "formatCells": "1", "formatColumns": "1", "formatRows": "1", "insertRows": "1", "deleteRows": "1",
                      "insertHyperlinks": "1", "sort": "1", "autoFilter": "1", "pivotTables": "1"})
    order = ["password", "sheet"] + [k for k in attrs if k not in ("password", "sheet")]
    tag = "<sheetProtection " + " ".join(f'{k}="{attrs[k]}"' for k in order if k in attrs) + "/>"
    calc = re.search(r"<sheetCalcPr\b[^>]*/>", xml)
    if calc:
        pos = calc.end()
    else:
        pos = None
        for pat in _AFTER:
            m = re.search(pat, xml)
            if m:
                pos = m.end()
                break
        if pos is None:
            raise ValueError("ورقة بلا sheetData")
    return xml[:pos] + tag + xml[pos:]


def _protect_workbook(xml, pw_hash):
    xml = re.sub(r"<workbookProtection\b[^>]*/>", "", xml)
    tag = '<workbookProtection lockStructure="1"' + (f' workbookPassword="{pw_hash}"' if pw_hash else "") + "/>"
    m = re.search(r"<bookViews\b", xml) or re.search(r"<sheets\b", xml)
    return xml[:m.start()] + tag + xml[m.start():]


def _lock_styles(styles):
    """ينسخ كل تنسيق خلية مفتوح (locked=0) بنسخة مقفلة في آخر cellXfs ← (styles الجديد، خريطة القديم→الجديد)."""
    m = re.search(r"(<cellXfs\b[^>]*>)(.*?)(</cellXfs>)", styles, re.S)
    if not m:
        return styles, {}
    xfs = re.findall(r"<xf\b[^>]*/>|<xf\b[^>]*>.*?</xf>", m.group(2), re.S)
    extra, remap = [], {}
    for i, xf in enumerate(xfs):
        if re.search(r'\blocked="(0|false)"', xf):
            remap[i] = len(xfs) + len(extra)
            extra.append(re.sub(r'\blocked="(0|false)"', 'locked="1"', xf))
    if not extra:
        return styles, {}
    head = re.sub(r'\bcount="\d+"', f'count="{len(xfs) + len(extra)}"', m.group(1))
    body = m.group(2) + "".join(extra)
    return styles[:m.start()] + head + body + m.group(3) + styles[m.end():], remap


def _relock_cells(xml, remap):
    """في ورقة مقفلة كاملة: كل خانة/صف/عمود بتنسيق مفتوح يأخذ نسخته المقفلة."""
    def fix(tag, attr):
        def sub(mm):
            t = mm.group(0)
            return re.sub(rf'\b{attr}="(\d+)"', lambda a: f'{attr}="{remap.get(int(a.group(1)), int(a.group(1)))}"', t)
        return sub
    xml = re.sub(r"<c\b[^>]*>", fix("c", "s"), xml)
    xml = re.sub(r"<row\b[^>]*>", fix("row", "s"), xml)
    xml = re.sub(r"<col\b[^>]*/?>", fix("col", "style"), xml)
    return xml


def lock_bytes(data, password="", full_weeks=(), structure=True):
    """data: محتوى xlsx ← محتوى xlsx مقفل. full_weeks: أرقام الأسابيع (0 = العودة) التي تُقفل كاملة."""
    pw_hash = hash_password(password) if password else ""
    full_weeks = set(full_weeks or ())
    src = zipfile.ZipFile(io.BytesIO(data))
    smap = _sheet_map(src)
    by_path = {p: n for n, p in smap.items()}
    remap = {}
    if full_weeks and "xl/styles.xml" in src.namelist():
        new_styles, remap = _lock_styles(src.read("xl/styles.xml").decode("utf-8"))
    out = io.BytesIO()
    locked = []
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for item in src.infolist():
            raw = src.read(item.filename)
            if item.filename == "xl/styles.xml" and remap:
                raw = new_styles.encode("utf-8")
            elif item.filename in by_path:
                name = by_path[item.filename]
                n = _week_no(name)
                full = n is not None and n in full_weeks
                xml = raw.decode("utf-8")
                if full and remap:
                    xml = _relock_cells(xml, remap)
                # الأوراق المخفية (التقويم والسجل) تُحمى أيضاً
                raw = _protect_sheet(xml, pw_hash, full).encode("utf-8")
                if full:
                    locked.append(name)
            elif item.filename == "xl/workbook.xml" and structure:
                raw = _protect_workbook(raw.decode("utf-8"), pw_hash).encode("utf-8")
            z.writestr(item, raw)
    return out.getvalue(), locked
