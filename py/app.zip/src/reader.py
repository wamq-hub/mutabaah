"""قراءة ملف متابعة المدرب (القالب) وحساب المؤشرات بنفس قواعد معادلات القالب — قراءة فقط، لا يُكتب في الملف.

كل ما يلزم يُقرأ من الملف نفسه: أوراق الأسابيع، والتقويم المخفي (أيام العمل مرقّمة)، وعمود المعرّف المخفي.
"""
import datetime as dt
import hashlib
import io
import os
import re
from pathlib import Path

from openpyxl import load_workbook

# أعمدة القالب (تطابق build_template)
COL = {"num": "A", "title": "B", "due": "C", "carry": "D", "eval": "E", "status": "F", "done": "G",
       "evidence": "H", "auto": "I", "approval": "J", "head_ev": "K", "override": "L", "notes": "M"}
ID_COL, KIND_COL = "AA", "AB"
SPEEDS = ["سريع", "متوسط", "ضعيف", "لا يوجد رد"]
SECTION = {"F": "ثابتة", "E": "طارئة", "C": "إبداعية"}


class TemplateError(Exception):
    pass


def _s(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).strip()


def _link(cell):
    """النص والرابط (إن وُجد) من خلية الشاهد."""
    text = _s(cell.value)
    url = ""
    if cell.hyperlink is not None:
        url = cell.hyperlink.target or ""
    if not url and re.match(r"^(https?://|\\\\|[A-Za-z]:\\)", text):
        url = text
    return text, url


def week_sheet_n(name):
    if name == "العودة":
        return 0
    m = re.fullmatch(r"أسبوع (\d+)", name)
    return int(m.group(1)) if m else None


def read_workbook(path, img_dir=None):
    """يرجع dict خام: info، calendar، weeks[{n, rows[]}]. img_dir: مجلد لحفظ صور الشواهد المدرجة."""
    path = Path(path)
    try:
        with open(path, "rb") as f:
            data = f.read()
    except PermissionError:
        raise TemplateError("تعذر فتح الملف (قد يكون مقفلاً أو غير متزامن بعد).")
    wb = load_workbook(io.BytesIO(data), data_only=False)
    if "التقويم" not in wb.sheetnames or "الملخص" not in wb.sheetnames:
        raise TemplateError("الملف ليس من قالب متابعة المهام (لا توجد ورقتا «الملخص» و«التقويم»).")

    s = wb["الملخص"]
    info = {"name": _s(s["C3"].value), "number": _s(s["C4"].value), "dept": _s(s["C5"].value),
            "unit": _s(s["C6"].value), "semester": _s(s["C7"].value)}

    c = wb["التقويم"]
    days = []
    for r in range(2, c.max_row + 1):
        lab, d, idx, wk = (c.cell(r, i).value for i in range(1, 5))
        if lab is None or idx is None:
            continue
        if isinstance(d, dt.datetime):
            d = d.date()
        days.append({"label": _s(lab), "date": d, "idx": int(idx), "week": int(wk)})
    medium = c["H1"].value
    cal = {"days": days, "by_label": {d["label"]: d for d in days}, "by_idx": {d["idx"]: d for d in days},
           "medium_max_delay": int(medium) if isinstance(medium, (int, float)) else 2,
           "deadline_time": _s(c["H2"].value) or "12:30"}

    weeks = []
    for name in wb.sheetnames:
        n = week_sheet_n(name)
        if n is None:
            continue
        ws = wb[name]
        wdays = [d for d in days if d["week"] == n]
        if not wdays:
            continue
        # الصور المدرجة: صف المرسى ← السطر، والعمود يحدد شاهد المدرب أو رئيس القسم
        pics = {}
        for im in getattr(ws, "_images", []):
            try:
                a = im.anchor._from
                row, col = a.row + 1, a.col + 1
                blob = im._data()
            except Exception:
                continue
            ext = (getattr(im, "format", None) or "png").lower()
            h = hashlib.md5(blob).hexdigest()[:16]
            fn = f"{h}.{ext}"
            if img_dir:
                os.makedirs(img_dir, exist_ok=True)
                fp = os.path.join(img_dir, fn)
                if not os.path.exists(fp):
                    with open(fp, "wb") as f:
                        f.write(blob)
            who = "head" if col >= 10 else "trainer"
            pics.setdefault(row, []).append({"file": fn, "who": who})
        rows = []
        for r in range(8, ws.max_row + 1):
            rid = _s(ws[f"{ID_COL}{r}"].value)
            if not rid or rid.startswith("K:") or rid[:1] not in SECTION:
                continue
            g = lambda k: ws[f"{COL[k]}{r}"]
            ev_t, ev_u = _link(g("evidence"))
            hv_t, hv_u = _link(g("head_ev"))
            row_pics = pics.get(r, [])
            rows.append({
                "row": r, "id": rid, "section": SECTION[rid[0]], "kind": _s(ws[f"{KIND_COL}{r}"].value),
                "title": _s(g("title").value), "due": _s(g("due").value), "carry": _s(g("carry").value),
                "eval": _s(g("eval").value), "status": _s(g("status").value), "done": _s(g("done").value),
                "evidence": ev_t, "evidence_url": ev_u, "approval": _s(g("approval").value),
                "head_ev": hv_t, "head_ev_url": hv_u, "override": _s(g("override").value), "notes": _s(g("notes").value),
                "pics": [p["file"] for p in row_pics if p["who"] == "trainer"],
                "head_pics": [p["file"] for p in row_pics if p["who"] == "head"],
            })
        weeks.append({"n": n, "sheet": name, "title": _s(ws["A1"].value).split("—")[-1].strip(),
                      "note": _s(ws["G3"].value), "days": wdays, "rows": rows})
    weeks.sort(key=lambda w: w["n"])
    wb.close()
    return {"info": info, "calendar": cal, "weeks": weeks, "mtime": os.path.getmtime(path)}


# ---------------------------------------------------------------- الحساب
def as_of_idx(cal, today):
    """ترتيب آخر يوم عمل حتى اليوم (0 قبل بداية الفصل)."""
    best = 0
    for d in cal["days"]:
        if d["date"] <= today:
            best = max(best, d["idx"])
    return best


def compute(raw, today=None):
    """يضيف لكل مهمة: الموعد والإنجاز والسرعة، ولكل أسبوع: المؤشرات والمرحّل، وللفصل: الإجماليات."""
    today = today or dt.date.today()
    cal = raw["calendar"]
    bl = cal["by_label"]
    mmax = cal["medium_max_delay"]
    tasks = []
    for w in raw["weeks"]:
        w["start_idx"] = w["days"][0]["idx"]
        w["end_idx"] = w["days"][-1]["idx"]
        w["start"] = w["days"][0]["date"]
        w["end"] = w["days"][-1]["date"]
        w["started"] = w["start"] <= today
        w["current"] = w["start"] <= today <= w["end"] + dt.timedelta(days=2)
        for t in w["rows"]:
            if not t["title"]:
                continue
            t["week"] = w["n"]
            t["week_title"] = w["title"]
            t["sheet"] = w["sheet"]
            dd = bl.get(t["due"]) if t["kind"] != "ongoing" else None
            t["due_idx"] = dd["idx"] if dd else None
            t["due_date"] = dd["date"] if dd else None
            dn = bl.get(t["done"])
            t["done_idx"] = dn["idx"] if dn else None
            t["done_date"] = dn["date"] if dn else None
            st = t["status"]
            if t["kind"] in ("ongoing", "creative") or st == "لا ينطبق":
                sp = "—"
            elif st == "منجز":
                if t["done_idx"] is None:
                    sp = "أدخل التاريخ"
                elif t["due_idx"] is None:
                    sp = "—"
                else:
                    delay = t["done_idx"] - t["due_idx"]
                    sp = "سريع" if delay <= 0 else ("متوسط" if delay <= mmax else "ضعيف")
                    t["delay"] = max(delay, 0)
            elif t["due_date"] is None:
                sp = ""
            elif today > t["due_date"]:
                sp = "لا يوجد رد" if not st else "متأخر"
            else:
                sp = "بانتظار"
            t["speed_auto"] = sp
            t["speed"] = t["override"] or sp
            t["counted"] = t["section"] != "إبداعية" and st != "لا ينطبق"
            t["approved_done"] = st == "منجز" and t["approval"] == "معتمد"
            t["pending_approval"] = st == "منجز" and not t["approval"]
            t["rejected"] = t["approval"] == "غير معتمد"
            t["has_evidence"] = bool(t["evidence"] or t["evidence_url"] or t["pics"])
            t["overdue"] = (t["section"] != "إبداعية" and t["kind"] != "ongoing" and st not in ("منجز", "لا ينطبق")
                            and t["due_date"] is not None and today > t["due_date"])
            tasks.append(t)

    weeks = raw["weeks"]
    for w in weeks:
        mine = [t for t in tasks if t["week"] == w["n"]]
        core = [t for t in mine if t["counted"]]
        S = w["start_idx"]
        carried = [t for t in tasks if t["week"] < w["n"] and t["carry"] == "نعم" and t["section"] != "إبداعية"
                   and t["due_idx"] is not None and t["due_idx"] < S and t["status"] != "لا ينطبق"
                   and (t["status"] != "منجز" or (t["done_idx"] or 0) >= S)]
        k = {"required": len(core), "approved": sum(t["approved_done"] for t in core),
             "pending": sum(t["pending_approval"] for t in core),
             "creative": sum(1 for t in mine if t["section"] == "إبداعية"),
             "creative_approved": sum(1 for t in mine if t["section"] == "إبداعية" and t["approval"] == "معتمد"),
             "carried": len(carried)}
        k["not_done"] = k["required"] - k["approved"] - k["pending"]
        k["pct"] = (k["approved"] / k["required"]) if k["required"] else None
        for sp in SPEEDS:
            k[sp] = sum(1 for t in core if t["speed"] == sp)
        # المتأخر الذي لم يُنجز بعد يُعدّ «لا يوجد رد» (قرار رئيس القسم)، ويبقى ظاهراً «متأخر» في الجداول
        k["لا يوجد رد"] += sum(1 for t in core if t["speed"] == "متأخر")
        w["kpi"] = k if w["started"] else {"creative": k["creative"], "creative_approved": k["creative_approved"]}
        w["carried"] = [t["id"] + "@" + str(t["week"]) for t in carried] if w["started"] else []
        w["tasks"] = mine

    started = [w for w in weeks if w["started"]]
    tot = {key: sum(w["kpi"].get(key, 0) for w in started) for key in
           ["required", "approved", "pending", "not_done", "carried"] + SPEEDS}
    tot["creative"] = sum(w["kpi"]["creative"] for w in weeks)
    tot["creative_approved"] = sum(w["kpi"]["creative_approved"] for w in weeks)
    tot["pct"] = tot["approved"] / tot["required"] if tot["required"] else None
    rated = sum(tot[s] for s in SPEEDS)
    tot["speed_share"] = {s: (tot[s] / rated if rated else None) for s in SPEEDS}
    cur = next((w for w in weeks if w["current"]), None) or (started[-1] if started else None)
    # المرحّل في الإجمالي = المفتوح عند بداية الأسبوع الحالي (جمع الأسابيع يكرر المهمة نفسها)
    tot["carried"] = cur["kpi"].get("carried", 0) if cur else 0
    open_now = [t for t in tasks if t["overdue"]]
    return {
        "info": raw["info"], "mtime": raw["mtime"], "weeks": weeks, "tasks": tasks, "total": tot,
        "current_week": cur["n"] if cur else None,
        "overdue": open_now,
        "no_evidence": [t for t in tasks if t["status"] == "منجز" and not t["has_evidence"] and t["kind"] != "ongoing"],
        "no_date": [t for t in tasks if t["status"] == "منجز" and t["kind"] != "ongoing" and t["done_idx"] is None and t["section"] != "إبداعية"],
        "pending_approval": [t for t in tasks if t["pending_approval"] or (t["section"] == "إبداعية" and not t["approval"])],
        "deadline_time": raw["calendar"]["deadline_time"],
        "today": today,
    }
