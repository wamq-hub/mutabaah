"""رسائل البريد (نص جاهز للنسخ) وتقارير المتابعة على الورق الرسمي."""
import base64
import datetime as dt
import html
import os

from hijridate import Gregorian

from names import short_name, shortener, honorific
from reader import SPEEDS

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
e = html.escape
AGENT = "وكيل شؤون المدربين"


def hijri(d=None):
    d = d or dt.date.today()
    h = Gregorian(d.year, d.month, d.day).to_hijri()
    return f"{h.year}/{h.month:02d}/{h.day:02d}"


def pct(x):
    # علامة RLM بعد النسبة حتى لا ينقلب ترتيب ما بعدها في النص العربي
    return "—" if x is None else f"{round(x * 100)}%\u200f"


def _bul(items):
    return "\n".join(f"- {x}" for x in items)


def _due_txt(t, time):
    if t.get("kind") == "ongoing":
        return "مستمرة"
    return f"{t['due']} الساعة {time}" if t.get("due") else "بلا موعد"


def _state(t):
    if t["status"] == "منجز":
        return "منجز، غير معتمد" if t["approval"] == "غير معتمد" else "منجز، بانتظار الاعتماد"
    return t["status"] or "لم تُعبَّأ"


def _week(res, n):
    return next((w for w in res["weeks"] if w["n"] == n), None)


def _carried_tasks(res, w):
    keys = set(w.get("carried") or [])
    return [t for t in res["tasks"] if f"{t['id']}@{t['week']}" in keys]


def _close():
    return "\n\nشاكرين تعاونكم، وتقبلوا خالص التحية والتقدير."


def _greet(to):
    return f"{to}\nالسلام عليكم ورحمة الله وبركاته،\n\n"


# ---------------------------------------------------------------- رسائل البريد
def messages(cfg, results, week_n):
    """results: [(trainer, res)] حيث res ناتج reader.compute أو None عند تعذر القراءة."""
    out = []
    head = cfg.get("head_name") or ""
    dept = cfg.get("dept") or ""
    sig = "\n\n" + "\n".join(x for x in ["رئيس قسم " + dept if dept else "رئيس القسم", head] if x)
    ok = [(tr, r) for tr, r in results if r]
    sn = shortener({tr["name"] for tr, _ in ok})

    def add(kind, key, label, to_email, subject, body):
        out.append({"kind": kind, "key": key, "label": label, "to": to_email or "", "subject": subject, "body": body})

    for tr, r in ok:
        w = _week(r, week_n)
        if not w:
            continue
        name = sn(tr["name"])
        to = f"سعادة {honorific(tr)}/ {name} المحترم"
        time = r["deadline_time"]
        mine = [t for t in w["tasks"] if t["section"] != "إبداعية"]
        open_ = [t for t in mine if t["status"] not in ("منجز", "لا ينطبق")]
        carried = [t for t in _carried_tasks(r, w) if t["status"] != "منجز"]
        # 1) تذكير بمهام الأسبوع
        if open_ or carried:
            body = (_greet(to) + f"نذكّركم بمهام {w['title']} ({w['days'][0]['label']} – {w['days'][-1]['label']}) التي لم تُسجَّل منجزة بعد:\n"
                    + _bul([f"{t['title']} — " + ("مهمة مستمرة" if t["kind"] == "ongoing" else f"آخر موعد: {_due_txt(t, time)}")
                            for t in open_] or ["لا يوجد"])
                    + (("\n\nومهام مرحّلة من أسابيع سابقة:\n" + _bul([f"{t['title']} ({t['week_title']})" for t in carried])) if carried else "")
                    + "\n\nنأمل تحديث الحالة وتاريخ الإنجاز والشاهد في ملف المتابعة عند الإنجاز." + _close() + sig)
            add("remind", f"remind:{tr['id']}", name, tr.get("email"), f"تذكير بمهام {w['title']}", body)
        # 2) متابعة المتأخر
        late = r["overdue"]
        noev = [t for t in r["no_evidence"] if t["week"] <= week_n]
        if late or noev:
            body = (_greet(to) + "نفيدكم بأن المهام الآتية تجاوزت موعدها ولم تُسجَّل منجزة في ملف المتابعة:\n"
                    + _bul([f"{t['title']} — {t['week_title']} — كان موعدها {t['due']}" for t in late] or ["لا يوجد"])
                    + (("\n\nومهام مسجلة منجزة بلا شاهد:\n" + _bul([f"{t['title']} ({t['week_title']})" for t in noev])) if noev else "")
                    + "\n\nنأمل استكمالها في أقرب وقت، علماً بأن «إنجاز المهام في الوقت المحدد» بند مستقل في نموذج تقييم الأداء."
                    + _close() + sig)
            add("late", f"late:{tr['id']}", name, tr.get("email"), "متابعة المهام المتأخرة", body)
        # 3) ملخص الأسبوع
        k = w.get("kpi", {})
        if w["started"]:
            done = [t for t in mine if t["approved_done"]]
            notd = [t for t in mine if t["counted"] and not t["approved_done"]]
            body = (_greet(to) + f"ملخص متابعة مهامكم في {w['title']}:\n"
                    + _bul([f"نسبة الإنجاز المعتمد: {pct(k.get('pct'))} ({k.get('approved', 0)} من {k.get('required', 0)})",
                            "سرعة الإنجاز: " + "، ".join(f"{s} {k.get(s, 0)}" for s in SPEEDS),
                            f"المهام الإبداعية: {k.get('creative', 0)}"])
                    + (("\n\nالمنجز المعتمد:\n" + _bul([t["title"] for t in done])) if done else "")
                    + (("\n\nلم يكتمل أو بانتظار الاعتماد:\n" + _bul([f"{t['title']} ({_state(t)})" for t in notd])) if notd else "")
                    + _close() + sig)
            add("summary", f"summary:{tr['id']}", name, tr.get("email"), f"ملخص متابعة مهام {w['title']}", body)

    # 4) رسالة عامة لكل المدربين بمهام الأسبوع الثابتة
    any_res = ok[0][1] if ok else None
    if any_res:
        w = _week(any_res, week_n)
        if w:
            fixed = [t for t in w["tasks"] if t["section"] == "ثابتة"]
            body = (_greet("الزملاء الأعزاء أعضاء هيئة التدريب بالقسم")
                    + f"مهام {w['title']} ({w['days'][0]['label']} – {w['days'][-1]['label']}):\n"
                    + _bul([f"{t['title']} — {_due_txt(t, any_res['deadline_time'])}" for t in fixed])
                    + (f"\n\nملاحظة الأسبوع: {w['note']}" if w.get("note") else "")
                    + "\n\nنأمل تحديث ملف المتابعة أولاً بأول (الحالة وتاريخ الإنجاز والشاهد)." + _close() + sig)
            add("all", "all", "جميع المدربين", "; ".join(tr.get("email", "") for tr, _ in ok if tr.get("email")),
                f"مهام {w['title']}", body)

    # 5) ملخص القسم لوكيل شؤون المدربين
    if ok:
        lines = []
        for tr, r in ok:
            w = _week(r, week_n)
            k = (w or {}).get("kpi", {})
            lines.append(f"{sn(tr['name'])}: {pct(k.get('pct'))} هذا الأسبوع، و{pct(r['total']['pct'])} للفصل، "
                         f"ومتأخر {len(r['overdue'])}")
        miss = [tr["name"] for tr, r in results if not r]
        body = (_greet(f"سعادة {AGENT} المحترم") + f"نفيدكم بملخص متابعة مهام أعضاء هيئة التدريب في قسم {dept} — "
                + (f"{_week(ok[0][1], week_n)['title']}" if _week(ok[0][1], week_n) else "") + ":\n" + _bul(lines)
                + (("\n\nتعذرت قراءة ملفات: " + "، ".join(short_name(m) for m in miss) + ".") if miss else "")
                + "\n\nومرفق تقرير القسم." + _close() + sig)
        add("agent", "agent", AGENT, "", f"ملخص متابعة مهام أعضاء هيئة التدريب — قسم {dept}", body)
    return out


# ---------------------------------------------------------------- التقارير
def _b64(*parts):
    p = os.path.join(HERE, *parts)
    if os.path.exists(p):
        with open(p, "rb") as f:
            return base64.b64encode(f.read()).decode()
    return ""


CLS = {"منجز": "ok", "معتمد": "ok", "سريع": "ok", "جزئي": "mid", "متوسط": "mid", "متأخر": "bad", "ضعيف": "bad",
       "لم ينجز": "bad", "لا يوجد رد": "bad", "غير معتمد": "bad", "لم تُعبَّأ": "bad", "بانتظار": "na", "—": "na"}


def mark(v):
    v = "—" if v in (None, "") else str(v)
    c = CLS.get(v, "")
    return f'<span class="{c}">{e(v)}</span>' if c else e(v)


def _sig(cfg):
    head = cfg.get("head_name") or "الاسم"
    return (f'<div class="blk" data-sec="9" data-sig="1"><div class="sigs"><div class="sig"><div class="t">رئيس قسم {e(cfg.get("dept") or "")}</div>'
            f'<div class="n">{e(head)}</div><div class="s">التوقيع:</div><div class="d">التاريخ: <span>{hijri()} هـ</span></div></div></div></div>')


def _page(title, sub, tabs, body, key):
    page = open(os.path.join(HERE, "templates", "letter_template.html"), encoding="utf-8").read()
    for k, v in {"@@TITLE@@": e(title), "@@EXAM@@": e(sub), "@@F_REG@@": _b64("assets", "fonts", "DINNextLTArabic-Regular.ttf"),
                 "@@F_MED@@": _b64("assets", "fonts", "DINNextLTArabic-Medium.ttf"), "@@LH@@": _b64("assets", "letterhead-a4-haql.jpg"),
                 "@@TABS@@": "".join(f'<button data-v="{n}">{e(lab)}</button>' for n, lab in tabs), "@@BODY@@": body,
                 "@@DATE@@": e(hijri() + " هـ"), "@@KEY@@": key, "@@ATT@@": "—"}.items():
        page = page.replace(k, v)
    return page


def _kpis(items):
    return '<div class="kpis">' + "".join(f'<div class="kpi {c}"><div class="v">{e(str(v))}</div><div class="l">{e(l)}</div></div>'
                                          for v, l, c in items) + "</div>"


def _ev(t):
    bits = []
    if t.get("evidence_url"):
        bits.append("رابط")
    elif t.get("evidence"):
        bits.append("وصف")
    if t.get("pics"):
        bits.append("صورة")
    return "، ".join(bits) or "—"


def trainer_week_html(cfg, tr, res, week_n):
    w = _week(res, week_n)
    k = w.get("kpi", {})
    name = short_name(tr["name"])
    title = f"تقرير متابعة مهام {w['title']}"
    sub = f"{name} · قسم {cfg.get('dept', '')} · {cfg.get('college', '')}"
    rows = ""
    for t in w["tasks"]:
        if t["section"] == "إبداعية":
            continue
        rows += (f"<tr><td class='r'>{e(t['title'])}</td><td>{e(t['section'])}</td><td>{e(t['due'] or '—')}</td>"
                 f"<td>{mark(t['status'] or 'لم تُعبَّأ')}</td><td>{e(t['done'] or '—')}</td><td>{mark(t['speed'])}</td>"
                 f"<td>{mark(t['approval'])}</td><td>{e(_ev(t))}</td></tr>")
    carried = _carried_tasks(res, w)
    crow = "".join(f"<tr><td class='r'>{e(t['title'])}</td><td>{e(t['week_title'])}</td><td>{e(t['due'])}</td>"
                   f"<td>{mark(t['status'] or 'لم تُعبَّأ')}</td><td>{e(t['done'] or '—')}</td></tr>" for t in carried)
    crea = [t for t in w["tasks"] if t["section"] == "إبداعية"]
    cr_rows = "".join(f"<tr><td class='r'>{e(t['title'])}</td><td>{e(t['done'] or '—')}</td><td>{e(_ev(t))}</td><td>{mark(t['approval'])}</td></tr>" for t in crea)
    notes = [f"{t['title']}: {t['notes']}" for t in w["tasks"] if t.get("notes")]
    intro = (f"يعرض هذا التقرير متابعة مهام {name} في {w['title']} ({w['days'][0]['label']} – {w['days'][-1]['label']})"
             + (f"؛ {w['note']}" if w.get("note") else "") + f". بلغت نسبة الإنجاز المعتمد {pct(k.get('pct'))}"
             f" ({k.get('approved', 0)} من {k.get('required', 0)} مهمة)"
             + (f"، وبقي {k.get('pending', 0)} بانتظار الاعتماد" if k.get("pending") else "") + ".")
    body = f'''
  <div class="blk" data-sec="1"><h1>{e(title)}</h1><div class="sub">{e(sub)}</div>
  <p style="margin-bottom:3mm"><b>إلى:</b> سعادة {honorific(tr)}/ {e(name)} المحترم، تحية طيبة وبعد،</p></div>
  <div class="blk" data-sec="1"><h2>أولاً: الملخص</h2><p>{e(intro)}</p></div>
  <div class="blk" data-sec="1">{_kpis([(k.get('required', 0), 'المطلوب', ''), (k.get('approved', 0), 'المنجز المعتمد', 'ok'),
                                        (k.get('pending', 0), 'بانتظار الاعتماد', 'mid'), (k.get('not_done', 0), 'غير منجز', 'bad'),
                                        (pct(k.get('pct')), 'نسبة الإنجاز', 'teal')])}</div>
  <div class="blk" data-sec="2"><h2>ثانياً: مهام الأسبوع</h2></div>
  <table class="blk tbl-sm" data-sec="2"><thead><tr><th>المهمة</th><th>النوع</th><th>آخر موعد</th><th>الحالة</th><th>تاريخ الإنجاز</th><th>السرعة</th><th>الاعتماد</th><th>الشاهد</th></tr></thead>
  <tbody>{rows or "<tr><td colspan='8'>لا توجد مهام.</td></tr>"}</tbody></table>
  <div class="blk" data-sec="3"><h2>ثالثاً: مهام مرحّلة من أسابيع سابقة</h2>{'' if carried else '<p>لا توجد مهام مرحّلة.</p>'}</div>
  {f"<table class='blk tbl-sm' data-sec='3'><thead><tr><th>المهمة</th><th>من</th><th>كان موعدها</th><th>الحالة</th><th>تاريخ الإنجاز</th></tr></thead><tbody>{crow}</tbody></table>" if carried else ''}
  <div class="blk" data-sec="4"><h2>رابعاً: المهام الإبداعية</h2>{'' if crea else '<p>لم تُسجَّل مهام إبداعية هذا الأسبوع.</p>'}</div>
  {f"<table class='blk tbl-sm' data-sec='4'><thead><tr><th>العمل</th><th>التاريخ</th><th>الشاهد</th><th>الاعتماد</th></tr></thead><tbody>{cr_rows}</tbody></table>" if crea else ''}
  <div class="blk" data-sec="5"><h2>خامساً: ملاحظات رئيس القسم</h2>{('<ul>' + ''.join(f'<li>{e(n)}</li>' for n in notes) + '</ul>') if notes else '<p>لا توجد ملاحظات.</p>'}</div>
  <div class="blk" data-sec="9"><h2>سادساً: الختام</h2><p>نشكر لكم جهودكم، ونأمل استكمال ما بقي من مهام وتحديث ملف المتابعة أولاً بأول.</p></div>
  {_sig(cfg)}'''
    tabs = [(1, "1 الملخص"), (2, "2 المهام"), (3, "3 المرحّلة"), (4, "4 الإبداعية"), (5, "5 الملاحظات"), (9, "6 الختام")]
    return _page(title, name, tabs, body, f"tasks-{tr['id']}-w{week_n}")


def trainer_semester_html(cfg, tr, res):
    name = short_name(tr["name"])
    T = res["total"]
    title = "تقرير متابعة مهام الفصل التدريبي"
    sub = f"{name} · قسم {cfg.get('dept', '')} · {res['info'].get('semester', '')}"
    wrows = ""
    for w in res["weeks"]:
        if not w["started"]:
            continue
        k = w["kpi"]
        wrows += (f"<tr><td class='r'>{e(w['title'])}</td><td>{k['required']}</td><td>{k['approved']}</td><td>{k['pending']}</td>"
                  f"<td><b>{pct(k['pct'])}</b></td>" + "".join(f"<td>{k[s]}</td>" for s in SPEEDS) + f"<td>{k['creative']}</td></tr>")
    wrows += (f"<tr class='tot'><td>الإجمالي</td><td>{T['required']}</td><td>{T['approved']}</td><td>{T['pending']}</td><td>{pct(T['pct'])}</td>"
              + "".join(f"<td>{T[s]}</td>" for s in SPEEDS) + f"<td>{T['creative']}</td></tr>")
    late = "".join(f"<tr><td class='r'>{e(t['title'])}</td><td>{e(t['week_title'])}</td><td>{e(t['due'])}</td><td>{mark(t['status'] or 'لم تُعبَّأ')}</td></tr>"
                   for t in res["overdue"])
    crea = [t for t in res["tasks"] if t["section"] == "إبداعية"]
    cr = "".join(f"<tr><td class='r'>{e(t['title'])}</td><td>{e(t['week_title'])}</td><td>{e(t['done'] or '—')}</td><td>{mark(t['approval'])}</td></tr>" for t in crea)
    sh = T["speed_share"]
    intro = (f"يعرض هذا التقرير متابعة مهام {name} في الأسابيع المنقضية من الفصل حتى {hijri(res['today'])} هـ: "
             f"نسبة الإنجاز المعتمد {pct(T['pct'])} ({T['approved']} من {T['required']})، "
             f"وتوزيع سرعة الإنجاز: سريع {pct(sh['سريع'])}، متوسط {pct(sh['متوسط'])}، ضعيف {pct(sh['ضعيف'])}، لا يوجد رد {pct(sh['لا يوجد رد'])}.")
    body = f'''
  <div class="blk" data-sec="1"><h1>{e(title)}</h1><div class="sub">{e(sub)}</div>
  <p style="margin-bottom:3mm"><b>إلى:</b> سعادة {honorific(tr)}/ {e(name)} المحترم، تحية طيبة وبعد،</p></div>
  <div class="blk" data-sec="1"><h2>أولاً: الملخص</h2><p>{e(intro)}</p></div>
  <div class="blk" data-sec="1">{_kpis([(pct(T['pct']), 'نسبة الإنجاز', 'teal'), (T['approved'], 'المنجز المعتمد', 'ok'),
                                        (len(res['overdue']), 'متأخر الآن', 'bad'), (T['carried'], 'مرحّل مفتوح', 'mid'), (T['creative'], 'مهام إبداعية', '')])}</div>
  <div class="blk" data-sec="2"><h2>ثانياً: الإنجاز أسبوعاً بأسبوع</h2></div>
  <table class="blk tbl-sm" data-sec="2"><thead><tr><th>الأسبوع</th><th>المطلوب</th><th>المعتمد</th><th>بانتظار</th><th>النسبة</th>{''.join(f'<th>{s}</th>' for s in SPEEDS)}<th>إبداعية</th></tr></thead><tbody>{wrows}</tbody></table>
  <div class="blk" data-sec="2"><p style="font-size:10.5px;color:#555">سرعة الإنجاز مؤشر لبند «إنجاز المهام في الوقت المحدد» (البند 20 في نموذج تقييم الأداء — 4 درجات).</p></div>
  <div class="blk" data-sec="3"><h2>ثالثاً: مهام متأخرة لم تُنجز</h2>{'' if late else '<p>لا توجد مهام متأخرة.</p>'}</div>
  {f"<table class='blk tbl-sm' data-sec='3'><thead><tr><th>المهمة</th><th>الأسبوع</th><th>كان موعدها</th><th>الحالة</th></tr></thead><tbody>{late}</tbody></table>" if late else ''}
  <div class="blk" data-sec="4"><h2>رابعاً: المهام الإبداعية</h2>{'' if crea else '<p>لم تُسجَّل مهام إبداعية.</p>'}</div>
  {f"<table class='blk tbl-sm' data-sec='4'><thead><tr><th>العمل</th><th>الأسبوع</th><th>التاريخ</th><th>الاعتماد</th></tr></thead><tbody>{cr}</tbody></table>" if crea else ''}
  <div class="blk" data-sec="9"><h2>خامساً: الختام</h2><p>نشكر لكم جهودكم خلال الفصل، ونأمل الاستمرار في تحديث ملف المتابعة أولاً بأول.</p></div>
  {_sig(cfg)}'''
    tabs = [(1, "1 الملخص"), (2, "2 الأسابيع"), (3, "3 المتأخر"), (4, "4 الإبداعية"), (9, "5 الختام")]
    return _page(title, name, tabs, body, f"tasks-{tr['id']}-sem")


def dept_week_html(cfg, results, week_n):
    ok = [(tr, r) for tr, r in results if r]
    sn = shortener({tr["name"] for tr, _ in ok})
    wt = next((_week(r, week_n)["title"] for _, r in ok if _week(r, week_n)), f"الأسبوع {week_n}")
    title = f"تقرير متابعة مهام أعضاء هيئة التدريب — {wt}"
    sub = f"قسم {cfg.get('dept', '')} · {cfg.get('college', '')}"
    rows, need = "", ""
    tot_req = tot_app = 0
    for tr, r in sorted(ok, key=lambda x: -(((_week(x[1], week_n) or {}).get("kpi") or {}).get("pct") or 0)):
        k = (_week(r, week_n) or {}).get("kpi", {})
        tot_req += k.get("required", 0)
        tot_app += k.get("approved", 0)
        rows += (f"<tr><td class='r'>{e(sn(tr['name']))}</td><td>{k.get('required', '—')}</td><td>{k.get('approved', '—')}</td>"
                 f"<td>{k.get('pending', '—')}</td><td><b>{pct(k.get('pct'))}</b></td>"
                 + "".join(f"<td>{k.get(s, '—')}</td>" for s in SPEEDS)
                 + f"<td>{k.get('carried', '—')}</td><td>{pct(r['total']['pct'])}</td></tr>")
        items = ([f"متأخر: {t['title']} ({t['week_title']})" for t in r["overdue"][:6]]
                 + [f"بلا شاهد: {t['title']}" for t in r["no_evidence"][:4]])
        if items:
            need += f"<tr><td class='r'>{e(sn(tr['name']))}</td><td class='r' style='font-size:10.5px'>{'<br>'.join('• ' + e(i) for i in items)}</td></tr>"
    miss = [tr["name"] for tr, r in results if not r]
    dpct = (tot_app / tot_req) if tot_req else None
    intro = (f"يعرض هذا التقرير متابعة مهام {len(ok)} من أعضاء هيئة التدريب في قسم {cfg.get('dept', '')} خلال {wt}: "
             f"بلغت نسبة الإنجاز المعتمد للقسم {pct(dpct)}" + (f"، وتعذرت قراءة {len(miss)} ملف" if miss else "") + ".")
    body = f'''
  <div class="blk" data-sec="1"><h1>{e(title)}</h1><div class="sub">{e(sub)}</div>
  <p style="margin-bottom:3mm"><b>إلى:</b> سعادة {AGENT} المحترم، تحية طيبة وبعد،</p></div>
  <div class="blk" data-sec="1"><h2>أولاً: الملخص</h2><p>{e(intro)}</p></div>
  <div class="blk" data-sec="2"><h2>ثانياً: حالة المدربين</h2></div>
  <table class="blk tbl-sm" data-sec="2"><thead><tr><th>المدرب</th><th>المطلوب</th><th>المعتمد</th><th>بانتظار</th><th>النسبة</th>{''.join(f'<th>{s}</th>' for s in SPEEDS)}<th>مرحّل</th><th>نسبة الفصل</th></tr></thead>
  <tbody>{rows or "<tr><td colspan='11'>لا توجد بيانات.</td></tr>"}</tbody></table>
  {('<div class="blk" data-sec="2"><p>تعذرت قراءة ملفات: ' + e("، ".join(short_name(m) for m in miss)) + '.</p></div>') if miss else ''}
  <div class="blk" data-sec="3"><h2>ثالثاً: ما يلزم متابعته</h2>{'' if need else '<p>لا يوجد ما يلزم متابعته.</p>'}</div>
  {f"<table class='blk tbl-sm' data-sec='3'><thead><tr><th style='width:38mm'>المدرب</th><th>ما يلزم</th></tr></thead><tbody>{need}</tbody></table>" if need else ''}
  <div class="blk" data-sec="9"><h2>رابعاً: الختام</h2><p>هذا ما لزم عرضه، ونأمل التكرم بالاطلاع، وتفضلوا بقبول فائق التحية والتقدير.</p></div>
  {_sig(cfg)}'''
    tabs = [(1, "1 الملخص"), (2, "2 المدربون"), (3, "3 المتابعة"), (9, "4 الختام")]
    return _page(title, sub, tabs, body, f"tasks-dept-w{week_n}")
