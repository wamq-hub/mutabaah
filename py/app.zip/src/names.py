# -*- coding: utf-8 -*-
"""اختصار أسماء المدربين في التقارير والخطابات: الاسم الأول والأخير فقط (بطلب المستخدم).
«نوار ساعد عايض المنصوري الثبيتي» ← «نوار الثبيتي»، و«عبد الله محمد باخشوين» ← «عبد الله باخشوين».
عند تشابه اسمين مختصرين داخل التقرير نفسه يُعاد الاسم الكامل لهما تجنباً للّبس."""
import re
from collections import Counter

_TITLES = ("م.", "د.", "أ.", "م", "د", "أ", "المهندس", "الدكتور", "الأستاذ")
_COMPOUND = ("عبد", "أبو", "ابو", "ام", "أم", "بن", "ابن")


def short_name(full):
    full = re.sub(r"^\s*[أامد]\s*[./]\s*", "", str(full or ""))   # «م.فهد» بلا مسافة
    t = [w for w in re.split(r"\s+", full.strip()) if w and w not in _TITLES]
    if len(t) <= 2:
        return " ".join(t)
    first = t[0]
    if first in _COMPOUND and len(t) > 2:
        first = t[0] + " " + t[1]
    last = t[-1]
    if len(t) >= 2 and t[-2] in ("آل", "ال", "بن", "ابن"):
        last = t[-2] + " " + t[-1]
    return first + " " + last


def short_map(names):
    m = {n: short_name(n) for n in names if n}
    c = Counter(m.values())
    return {n: (sh if c[sh] == 1 else n) for n, sh in m.items()}


def shortener(names):
    """يرجع دالة sn(name) تعمل على مجموعة أسماء معروفة مسبقاً."""
    m = short_map(names)
    return lambda n: m.get(n, short_name(n))


# ---------------------------------------------------------------- اللقب في التحية
HONORS = {"أ": "الأستاذ", "م": "المهندس", "د": "الدكتور"}
_HONOR_RE = re.compile(r"^\s*(?:(الأستاذ|الاستاذ|أستاذ|المهندس|مهندس|الدكتور|دكتور)\s|([أامد])\s*[./]|([أامد])\s)")
_WORD = {"الأستاذ": "أ", "الاستاذ": "أ", "أستاذ": "أ", "المهندس": "م", "مهندس": "م", "الدكتور": "د", "دكتور": "د"}


def honor_from_name(full):
    """يقرأ اللقب من بداية الاسم («م. فهد» أو «م.فهد» أو «المهندس فهد»)، ويرجع "" إن لم يوجد."""
    m = _HONOR_RE.match(str(full or ""))
    if not m:
        return ""
    if m.group(1):
        return _WORD[m.group(1)]
    c = m.group(2) or m.group(3)
    return "أ" if c in ("أ", "ا") else c


def honor_code(tr):
    """اللقب المختار في بطاقة المدرب، وإلا المقروء من الاسم، وإلا «أ» كما كانت الرسائل سابقاً."""
    c = str((tr or {}).get("honor") or "").strip()
    return c if c in HONORS else (honor_from_name((tr or {}).get("name")) or "أ")


def honorific(tr):
    return HONORS[honor_code(tr)]
