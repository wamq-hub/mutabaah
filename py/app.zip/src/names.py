# -*- coding: utf-8 -*-
"""اختصار أسماء المدربين في التقارير والخطابات: الاسم الأول والأخير فقط (بطلب المستخدم).
«نوار ساعد عايض المنصوري الثبيتي» ← «نوار الثبيتي»، و«عبد الله محمد باخشوين» ← «عبد الله باخشوين».
عند تشابه اسمين مختصرين داخل التقرير نفسه يُعاد الاسم الكامل لهما تجنباً للّبس."""
import re
from collections import Counter

_TITLES = ("م.", "د.", "أ.", "م", "د", "أ", "المهندس", "الدكتور", "الأستاذ")
_COMPOUND = ("عبد", "أبو", "ابو", "ام", "أم", "بن", "ابن")


def short_name(full):
    t = [w for w in re.split(r"\s+", str(full or "").strip()) if w and w not in _TITLES]
    if len(t) <= 2:
        return " ".join(t)
    first = t[0]
    if first in _COMPOUND and len(t) > 2:
        first = t[0] + " " + t[1]
    last = t[-1]
    if len(t) >= 2 and t[-2] in ("آل", "ال", "بن", "ابن"):
        last = t[-2] + " " + t[-1]
    return first + " " + last


def short_map(names):
    m = {n: short_name(n) for n in names if n}
    c = Counter(m.values())
    return {n: (sh if c[sh] == 1 else n) for n, sh in m.items()}


def shortener(names):
    """يرجع دالة sn(name) تعمل على مجموعة أسماء معروفة مسبقاً."""
    m = short_map(names)
    return lambda n: m.get(n, short_name(n))
