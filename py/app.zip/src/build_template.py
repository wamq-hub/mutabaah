"""يبني قالب Excel لمتابعة مهام عضو هيئة التدريب: ورقة لكل أسبوع + ملخص + شرح + أهمية المهام.

الاستخدام:
    python src/build_template.py                      # قالب فارغ
    python src/build_template.py --name "م. فلان" --dept "التقنية الإلكترونية"
"""
import argparse
from pathlib import Path

from openpyxl import Workbook
from openpyxl.formatting.rule import FormulaRule, DataBarRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Protection, Side
from openpyxl.styles.differential import DifferentialStyle
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.workbook.protection import WorkbookProtection
from openpyxl.worksheet.protection import SheetProtection

from semester import ROOT, load_semester, load_tasks, resolve_due, tasks_for_week

CAL = "'التقويم'"
LOG = "'السجل'"
SUM = "'الملخص'"

STATUS = ["منجز", "جزئي", "لم ينجز", "لا ينطبق"]
APPROVAL = ["معتمد", "غير معتمد"]
SPEEDS = ["سريع", "متوسط", "ضعيف", "لا يوجد رد"]

# ألوان
TEAL = "15616D"
TEAL_L = "E3F0F1"
TRAINER_H = "D6E7F5"
HEAD_H = "FBE3CF"
AUTO_H = "E7E6E6"
SECTION = "BFDDE0"
CARRY_BG = "F3F3F3"
FONT = "Arial"

thin = Side(style="thin", color="9FB7BA")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True, readingOrder=2)
RIGHT = Alignment(horizontal="right", vertical="center", wrap_text=True, readingOrder=2)


def fill(c):
    return PatternFill(start_color=c, end_color=c, fill_type="solid")


def font(size=11, bold=False, color="000000"):
    return Font(name=FONT, size=size, bold=bold, color=color)


def dxf(bg, fg="000000", bold=False):
    # تعبئة التنسيق الشرطي تحتاج bgColor مع fgColor وإلا لا تظهر في Excel
    return DifferentialStyle(fill=PatternFill(start_color=bg, end_color=bg, bgColor=bg, fill_type="solid"),
                             font=Font(color=fg, bold=bold))


def cf(ws, rng, formula, bg, fg="000000", bold=False):
    r = FormulaRule(formula=[formula])
    r.dxf = dxf(bg, fg, bold)
    ws.conditional_formatting.add(rng, r)


def put(ws, ref, value=None, *, f=None, bg=None, align=CENTER, border=True, fmt=None, locked=True):
    c = ws[ref]
    if value is not None:
        c.value = value
    c.font = f or font()
    c.alignment = align
    if bg:
        c.fill = fill(bg)
    if border:
        c.border = BORDER
    if fmt:
        c.number_format = fmt
    c.protection = Protection(locked=locked)
    return c


def merge(ws, rng, value=None, **kw):
    first = rng.split(":")[0]
    put(ws, first, value, **kw)
    ws.merge_cells(rng)
    if kw.get("border", True):
        for row in ws[rng]:
            for c in row:
                c.border = BORDER
    return ws[first]


def eval_label(cfg, nums):
    names = {e["n"]: e["name"] for e in cfg["eval_items"]}
    return " + ".join(f"{n} - {names[n]}" for n in nums)


def landscape(ws, fit_height=0):
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = fit_height


PASSWORD = ""   # الرقم السري لرئيس القسم (يُضبط في build)، والفارغ = حماية بلا رقم سري


def protect(ws, pictures=False):
    # pictures: يسمح بإدراج صور الشواهد فوق الأسطر مع بقاء المعادلات محمية
    ws.protection = SheetProtection(sheet=True, formatColumns=False, formatRows=False,
                                    selectLockedCells=False, selectUnlockedCells=False,
                                    objects=not pictures, insertHyperlinks=False)
    if PASSWORD:
        ws.protection.password = PASSWORD


# ------------------------------------------------------------------ التقويم (مخفية)
def build_calendar(wb, sem, cfg):
    ws = wb.create_sheet("التقويم")
    ws.sheet_view.rightToLeft = True
    for i, h in enumerate(["اليوم", "التاريخ", "الترتيب", "الأسبوع", "الهجري"], 1):
        ws.cell(1, i, h).font = font(bold=True)
    for d in sem["days"]:
        r = d["idx"] + 1
        ws.cell(r, 1, d["label"])
        ws.cell(r, 2, d["date"]).number_format = "yyyy-mm-dd"
        ws.cell(r, 3, d["idx"])
        ws.cell(r, 4, d["week"])
        ws.cell(r, 5, d["hijri"])
    ws["G1"], ws["H1"] = "أقصى تأخير لسرعة «متوسط» (أيام عمل)", cfg["speed"]["medium_max_delay"]
    ws["G2"], ws["H2"] = "وقت التسليم", cfg["deadline_time"]
    ws["J1"] = "بنود نموذج التقييم"
    for i, e in enumerate(cfg["eval_items"], 2):
        ws.cell(i, 10, f"{e['n']} - {e['name']}")
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["G"].width = 34
    ws.column_dimensions["J"].width = 50
    ws.sheet_state = "hidden"
    return ws


# ------------------------------------------------------------------ ورقة الأسبوع
COLS = {"A": 5, "B": 44, "C": 21, "D": 8, "E": 28, "F": 12, "G": 21, "H": 28,
        "I": 13, "J": 13, "K": 26, "L": 13, "M": 30}
# أعمدة مساعدة مخفية (يقرأها البرنامج): المعرّف، النوع، ترتيب الموعد، ترتيب الإنجاز، السرعة النهائية، المؤشرات
ID, KIND, DL, DONE, FIN, KL, KV = "AA", "AB", "AC", "AD", "AE", "AH", "AI"
HIDDEN = ["N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", ID, KIND, DL, DONE, FIN, "AF", "AG", KL, KV]
HEAD = ["م", "المهمة", "آخر موعد (الساعة {t})", "يُرحّل", "بند نموذج التقييم",
        "الحالة", "تاريخ الإنجاز", "الشاهد (رابط أو وصف)", "سرعة الإنجاز",
        "اعتماد رئيس القسم", "شاهد رئيس القسم (رابط أو صورة)", "تعديل السرعة", "ملاحظات رئيس القسم / سبب التعديل"]


def build_week(wb, sem, cfg, w, log_rows, log_len_ref):
    n = w["n"]
    ws = wb.create_sheet(w["sheet"])
    ws.sheet_view.rightToLeft = True
    ws.sheet_view.zoomScale = 90
    ws.sheet_properties.tabColor = "8FC1C6" if n else "C9A227"
    for col, wdt in COLS.items():
        ws.column_dimensions[col].width = wdt
    for col in HIDDEN:
        ws.column_dimensions[col].hidden = True

    first, last = w["days"][0], w["days"][-1]
    cal_last = len(sem["days"]) + 1
    date_list = f"{CAL}!$A${first['idx'] + 1}:$A${cal_last}"
    cal_a = f"{CAL}!$A$2:$A${cal_last}"
    cal_b = f"{CAL}!$B$2:$B${cal_last}"

    # الرأس
    merge(ws, "A1:M1", f"متابعة مهام عضو هيئة التدريب — {w['title']}", f=font(15, True, "FFFFFF"), bg=TEAL)
    ws.row_dimensions[1].height = 30
    put(ws, "A2", "المدرب", f=font(bold=True), bg=TEAL_L)
    merge(ws, "B2:C2", f"=IF({SUM}!$C$3=\"\",\"(اكتب اسمك في ورقة الملخص)\",{SUM}!$C$3)", align=RIGHT)
    put(ws, "D2", "القسم", f=font(bold=True), bg=TEAL_L)
    merge(ws, "E2:F2", f"=IF({SUM}!$C$5=\"\",\"\",{SUM}!$C$5)", align=RIGHT)
    put(ws, "G2", "الفصل", f=font(bold=True), bg=TEAL_L)
    merge(ws, "H2:I2", sem["title"])
    put(ws, "J2", "أيام العمل", f=font(bold=True), bg=TEAL_L)
    merge(ws, "K2:M2", len(w["days"]))

    put(ws, "A3", "من", f=font(bold=True), bg=TEAL_L)
    merge(ws, "B3:C3", f"{DAY_LABEL(first)}", align=RIGHT)
    put(ws, "D3", "إلى", f=font(bold=True), bg=TEAL_L)
    merge(ws, "E3:F3", f"{DAY_LABEL(last)}")
    note = w["note"]
    if w["off"]:
        note = (note + " — " if note else "") + "لا دوام: " + "، ".join(w["off"])
    merge(ws, "G3:M3", note or "", f=font(10, True, "B42318"), align=RIGHT)
    ws.row_dimensions[3].height = 30 if len(note) > 60 else 20

    # المؤشرات
    put(ws, "A4", "", bg=TEAL_L)
    put(ws, "B4", "نسبة الإنجاز المعتمد لهذا الأسبوع", f=font(bold=True), bg=TEAL_L)
    put(ws, "C4", f"=IF(${KV}$6=\"\",\"—\",${KV}$6)", f=font(13, True, TEAL), fmt="0%")
    merge(ws, "D4:E4", "بانتظار اعتماد رئيس القسم", f=font(bold=True), bg=TEAL_L)
    put(ws, "F4", f"=${KV}$4", f=font(13, True))
    merge(ws, "G4:H4", "مهام مرحّلة من أسابيع سابقة لم تُنجز", f=font(bold=True), bg=TEAL_L)
    put(ws, "I4", f"=${KV}$13", f=font(13, True, "B42318"))
    merge(ws, "J4:L4", "مهام إبداعية", f=font(bold=True), bg=TEAL_L)
    put(ws, "M4", f"=${KV}$11", f=font(13, True))

    # رؤوس الجدول
    merge(ws, "A6:E6", "المهمة", f=font(bold=True, color="FFFFFF"), bg=TEAL)
    merge(ws, "F6:H6", "يعبّئه المدرب", f=font(bold=True), bg=TRAINER_H)
    put(ws, "I6", "تلقائي", f=font(bold=True), bg=AUTO_H)
    merge(ws, "J6:M6", "يعبّئه رئيس القسم", f=font(bold=True), bg=HEAD_H)
    for i, h in enumerate(HEAD, 1):
        col = get_column_letter(i)
        bg = TEAL_L if i <= 5 else TRAINER_H if i <= 8 else AUTO_H if i == 9 else HEAD_H
        put(ws, f"{col}7", h.format(t=cfg["deadline_time"]), f=font(10, True), bg=bg)
    ws.row_dimensions[7].height = 32

    r = 8
    blocks = {}

    def section(title, color=SECTION):
        nonlocal r
        merge(ws, f"A{r}:M{r}", title, f=font(11, True), bg=color, align=RIGHT)
        r += 1

    def task_row(num, kind, rid, title=None, due=None, carry=None, ev=None, editable_task=False):
        nonlocal r
        put(ws, f"A{r}", num)
        put(ws, f"B{r}", title, align=RIGHT, locked=not editable_task)
        if kind == "ongoing":
            put(ws, f"C{r}", "مستمرة")
            ws[f"{DL}{r}"] = ""
        elif due is not None:
            put(ws, f"C{r}", due["label"], locked=not editable_task)
            ws[f"{DL}{r}"] = f"=IF(C{r}=\"\",\"\",IFERROR(MATCH(C{r},{cal_a},0),\"\"))" if editable_task else due["idx"]
        else:
            put(ws, f"C{r}", None, locked=not editable_task)
            ws[f"{DL}{r}"] = f"=IF(C{r}=\"\",\"\",IFERROR(MATCH(C{r},{cal_a},0),\"\"))"
        put(ws, f"D{r}", carry, locked=not editable_task)
        put(ws, f"E{r}", ev, f=font(9), align=RIGHT, locked=not editable_task and kind != "creative")
        for col in "FGH":
            put(ws, f"{col}{r}", None, align=RIGHT if col == "H" else CENTER, locked=False)
        put(ws, f"I{r}",
            f"=IF(B{r}=\"\",\"\",IF(OR({KIND}{r}=\"ongoing\",{KIND}{r}=\"creative\",F{r}=\"لا ينطبق\"),\"—\","
            f"IF(F{r}=\"منجز\",IF({DONE}{r}=\"\",\"أدخل التاريخ\",IF({DL}{r}=\"\",\"—\",IF({DONE}{r}-{DL}{r}<=0,\"سريع\","
            f"IF({DONE}{r}-{DL}{r}<={CAL}!$H$1,\"متوسط\",\"ضعيف\")))),"
            f"IF({DL}{r}=\"\",\"\",IF(TODAY()>INDEX({cal_b},{DL}{r}),IF(F{r}=\"\",\"لا يوجد رد\",\"متأخر\"),\"بانتظار\")))))",
            bg=AUTO_H, f=font(10, True))
        for col in "JKLM":
            put(ws, f"{col}{r}", None, align=RIGHT if col in "KM" else CENTER, locked=False)
        ws[f"{ID}{r}"] = rid
        ws[f"{KIND}{r}"] = kind
        ws[f"{DONE}{r}"] = f"=IF(G{r}=\"\",\"\",IFERROR(MATCH(G{r},{cal_a},0),\"\"))"
        ws[f"{FIN}{r}"] = f"=IF(L{r}<>\"\",L{r},I{r})"
        ws.row_dimensions[r].height = 34
        r += 1

    # المهام الثابتة
    spare_hint = " — لإضافة سطر: حدّد السطرين حول الأسطر المخفية ← زر الفأرة الأيمن ← إظهار"
    section("أولاً: المهام الثابتة لهذا الأسبوع" + spare_hint)
    s = r
    fixed = tasks_for_week(cfg, n)
    for i, t in enumerate(fixed, 1):
        kind = "ongoing" if t["due"]["rule"] == "ongoing" else "deliverable"
        due = resolve_due(sem, n, t["due"])
        task_row(i, kind, f"F:{t['id']}", t["title"], due, "نعم" if t["carry"] else "لا", eval_label(cfg, t["eval"]))
    # أسطر يكتب فيها رئيس القسم مهامه: ظاهرة في القالب المفرغ، والاحتياطية مخفية
    spare_fixed = []
    shown = cfg.get("blank_fixed_rows", 0) if cfg.get("blank") else 0
    for j in range(shown + cfg["fixed_spare_rows"]):
        task_row(len(fixed) + j + 1, "deliverable", f"F:X{j + 1}", None, None, "نعم", None, editable_task=True)
        if j >= shown:
            ws.row_dimensions[r - 1].hidden = True
        spare_fixed.append(r - 1)
    blocks["fixed"] = (s, r - 1)

    # المرحّلة
    S = first["idx"]
    cond = (f"({LOG}!$A$2:$A${log_len_ref}<{n})*({LOG}!$B$2:$B${log_len_ref}<>\"\")*({LOG}!$C$2:$C${log_len_ref}=\"نعم\")"
            f"*({LOG}!$F$2:$F${log_len_ref}<{S})*({LOG}!$D$2:$D${log_len_ref}<>\"لا ينطبق\")"
            f"*((({LOG}!$D$2:$D${log_len_ref}<>\"منجز\")+({LOG}!$E$2:$E${log_len_ref}>={S}))>0)")
    if n > 0:
        section("ثانياً: مهام مرحّلة من أسابيع سابقة لم تُنجز قبل بداية هذا الأسبوع (للاطلاع — تُحدَّث حالتها في ورقة أسبوعها)", "E4E4E4")
        s = r
        for k in range(1, cfg["carried_rows"] + 1):
            ws[f"{ID}{r}"] = f"K:{k}"
            ws[f"{KIND}{r}"] = f"=IFERROR(_xlfn.AGGREGATE(15,6,(ROW({LOG}!$A$2:$A${log_len_ref})-1)/({cond}),{k}),\"\")"

            def lk(col):
                return f"=IF(${KIND}{r}=\"\",\"\",INDEX({LOG}!${col}$2:${col}${log_len_ref},${KIND}{r}))"
            put(ws, f"A{r}", f"=IF(${KIND}{r}=\"\",\"\",\"م{k}\")", bg=CARRY_BG)
            put(ws, f"B{r}", lk("B"), align=RIGHT, bg=CARRY_BG)
            put(ws, f"C{r}", lk("G"), bg=CARRY_BG)
            put(ws, f"D{r}", f"=IF(${KIND}{r}=\"\",\"\",\"نعم\")", bg=CARRY_BG)
            put(ws, f"E{r}", f"=IF(${KIND}{r}=\"\",\"\",\"من: \"&INDEX({LOG}!$J$2:$J${log_len_ref},${KIND}{r}))", f=font(9), bg=CARRY_BG)
            put(ws, f"F{r}", f"=IF(${KIND}{r}=\"\",\"\",IF(INDEX({LOG}!$D$2:$D${log_len_ref},${KIND}{r})=\"\",\"لم تُعبَّأ\",INDEX({LOG}!$D$2:$D${log_len_ref},${KIND}{r})))", bg=CARRY_BG)
            put(ws, f"G{r}", lk("H"), bg=CARRY_BG)
            put(ws, f"H{r}", f"=IF(${KIND}{r}=\"\",\"\",\"حدّثها في ورقة «\"&INDEX({LOG}!$K$2:$K${log_len_ref},${KIND}{r})&\"»\")", f=font(9), bg=CARRY_BG)
            put(ws, f"I{r}", lk("I"), f=font(10, True), bg=CARRY_BG)
            for col in "JKLM":
                put(ws, f"{col}{r}", None, bg=CARRY_BG)
            ws[f"{FIN}{r}"] = f"=I{r}"
            ws.row_dimensions[r].height = 30
            r += 1
        blocks["carried"] = (s, r - 1)

    # الطارئة
    em = [e for e in cfg["emergency"] if e["week"] == n]
    section(("ثالثاً" if n else "ثانياً") + ": المهام الطارئة (يضيفها رئيس القسم خلال الأسبوع أو عند وصول بريد بها)" + spare_hint)
    s = r
    visible = max(cfg["emergency_rows"], len(em))
    for i in range(visible + cfg["emergency_spare_rows"]):
        if i < len(em):
            e = em[i]
            task_row(f"ط{i + 1}", "deliverable", f"E:{i + 1}", e["title"], resolve_due(sem, n, e["due"]), "نعم",
                     eval_label(cfg, e["eval"]), editable_task=True)
        else:
            task_row(f"ط{i + 1}", "deliverable", f"E:{i + 1}", None, None, "نعم", None, editable_task=True)
        if i >= visible:
            ws.row_dimensions[r - 1].hidden = True
    blocks["emergency"] = (s, r - 1)

    # الإبداعية
    section(("رابعاً" if n else "ثالثاً") + ": المهام الإبداعية من قبل المدرب (ندوات، دورات، ورش عمل، مبادرات...)" + spare_hint)
    s = r
    for i in range(cfg["creative_rows"] + cfg["creative_spare_rows"]):
        put(ws, f"A{r}", f"إ{i + 1}")
        put(ws, f"B{r}", None, align=RIGHT, locked=False)
        put(ws, f"C{r}", "—")
        put(ws, f"D{r}", "—")
        put(ws, f"E{r}", eval_label(cfg, [8, 14]), f=font(9), align=RIGHT, locked=False)
        for col in "FGH":
            put(ws, f"{col}{r}", None, align=RIGHT if col == "H" else CENTER, locked=False)
        put(ws, f"I{r}", f"=IF(B{r}=\"\",\"\",\"—\")", bg=AUTO_H)
        for col in "JKLM":
            put(ws, f"{col}{r}", None, align=RIGHT if col in "KM" else CENTER, locked=False)
        ws[f"{ID}{r}"] = f"C:{i + 1}"
        ws[f"{KIND}{r}"] = "creative"
        ws[f"{DONE}{r}"] = f"=IF(G{r}=\"\",\"\",IFERROR(MATCH(G{r},{cal_a},0),\"\"))"
        ws.row_dimensions[r].height = 30
        if i >= cfg["creative_rows"]:
            ws.row_dimensions[r].hidden = True
        r += 1
    blocks["creative"] = (s, r - 1)
    last_row = r - 1

    # سجل المهام (للترحيل)
    for key in ("fixed", "emergency"):
        a, b = blocks[key]
        for rr in range(a, b + 1):
            log_rows.append((n, w["title"], w["sheet"], rr))

    # قوائم منسدلة
    def dv(formula, rngs, prompt=None):
        d = DataValidation(type="list", formula1=formula, allow_blank=True, showErrorMessage=True,
                           errorTitle="قيمة غير مقبولة", error="اختر من القائمة.")
        if prompt:
            d.promptTitle, d.prompt, d.showInputMessage = "تنبيه", prompt, True
        ws.add_data_validation(d)
        for x in rngs:
            d.add(x)

    inputs = [blocks["fixed"], blocks["emergency"], blocks["creative"]]
    rows = lambda col: [f"{col}{a}:{col}{b}" for a, b in inputs if b >= a]
    dv('"' + ",".join(STATUS) + '"', rows("F"))
    dv(date_list, rows("G"), "اختر يوم الإنجاز من القائمة.")
    dv('"' + ",".join(APPROVAL) + '"', rows("J"))
    dv('"' + ",".join(SPEEDS) + '"', rows("L"), "اتركها فارغة لتُعتمد السرعة التلقائية، واكتب السبب في الملاحظات عند تعديلها.")
    ea, eb = blocks["emergency"]
    spare = [f"{{c}}{x}" for x in spare_fixed]
    dv(date_list, [f"C{ea}:C{eb}"] + [x.format(c="C") for x in spare], "اختر يوم آخر موعد للتسليم.")
    dv('"نعم,لا"', [f"D{ea}:D{eb}"] + [x.format(c="D") for x in spare])
    dv(f"{CAL}!$J$2:$J$21", [f"E{ea}:E{eb}", f"E{blocks['creative'][0]}:E{blocks['creative'][1]}"]
       + [x.format(c="E") for x in spare])

    # تنسيق شرطي
    for col in "FGH":
        for a, b in inputs:
            cf(ws, f"{col}{a}:{col}{b}", f"AND($B{a}<>\"\",{col}{a}=\"\")", "FFF4CC")
    for a, b in [blocks["fixed"], blocks["emergency"]]:
        cf(ws, f"J{a}:J{b}", f"AND($F{a}=\"منجز\",$J{a}=\"\")", "FFF4CC")
    a0, b0 = 8, last_row
    for txt, bg, fg in [("منجز", "D1F0D8", "1E6B34"), ("جزئي", "FFE8B3", "7A4B00"), ("لم ينجز", "F8D0CC", "8C1D18"),
                        ("لا ينطبق", "E7E6E6", "555555"), ("لم تُعبَّأ", "F8D0CC", "8C1D18")]:
        cf(ws, f"F{a0}:F{b0}", f"F{a0}=\"{txt}\"", bg, fg, True)
    for txt, bg, fg in [("سريع", "D1F0D8", "1E6B34"), ("متوسط", "FFE8B3", "7A4B00"), ("ضعيف", "F9C9A8", "8A3B00"),
                        ("لا يوجد رد", "F4B6B0", "8C1D18"), ("متأخر", "F8D0CC", "8C1D18"), ("أدخل التاريخ", "FFF4CC", "7A4B00")]:
        for col in "IL":
            cf(ws, f"{col}{a0}:{col}{b0}", f"{col}{a0}=\"{txt}\"", bg, fg, True)
    cf(ws, f"J{a0}:J{b0}", f"J{a0}=\"معتمد\"", "D1F0D8", "1E6B34", True)
    cf(ws, f"J{a0}:J{b0}", f"J{a0}=\"غير معتمد\"", "F8D0CC", "8C1D18", True)

    # المؤشرات المخفية (T: الاسم، U: القيمة)
    fa, fb = blocks["fixed"]
    ea, eb = blocks["emergency"]
    ca, cb = blocks["creative"]

    def both(fn, col, *crit):
        parts = []
        for a, b in ((fa, fb), (ea, eb)):
            if b < a:
                continue
            args = ",".join(f"{c}{a}:{c}{b},{v}" for c, v in crit)
            parts.append(f"{fn}({col}{a}:{col}{b},\"<>\",{args})" if col else f"{fn}({args})")
        return "+".join(parts) or "0"

    kpis = [
        ("المطلوب", both("COUNTIFS", "B", ("F", '"<>لا ينطبق"'))),
        ("المنجز المعتمد", both("COUNTIFS", "B", ("F", '"منجز"'), ("J", '"معتمد"'))),
        ("بانتظار الاعتماد", both("COUNTIFS", "B", ("F", '"منجز"'), ("J", '""'))),
        ("غير منجز", f"N({KV}2)-N({KV}3)-N({KV}4)"),
        ("النسبة", f"IF(N({KV}2)=0,\"\",{KV}3/{KV}2)"),
    ]
    for sp in SPEEDS:
        # المتأخر الذي لم يُنجز يُعدّ ضمن «لا يوجد رد»
        names = [sp, "متأخر"] if sp == "لا يوجد رد" else [sp]
        kpis.append((sp, "+".join(f"COUNTIF({FIN}{a}:{FIN}{b},\"{x}\")" for a, b in ((fa, fb), (ea, eb)) if b >= a for x in names)))
    kpis += [
        ("إبداعية", f"COUNTIF(B{ca}:B{cb},\"?*\")"),
        ("إبداعية معتمدة", f"COUNTIFS(B{ca}:B{cb},\"?*\",J{ca}:J{cb},\"معتمد\")"),
        ("مرحّلة غير منجزة", f"SUMPRODUCT({cond})" if n > 0 else "0"),
    ]
    # الأسبوع الذي لم يبدأ بعد تبقى مؤشراته فارغة حتى لا تُنزل نسبة الفصل (عدا الإبداعية)
    ws[f"{KL}14"], ws[f"{KV}14"] = "بداية الأسبوع", first["date"]
    ws[f"{KV}14"].number_format = "yyyy-mm-dd"
    for i, (lbl, fml) in enumerate(kpis, 2):
        ws[f"{KL}{i}"] = lbl
        ws[f"{KV}{i}"] = "=" + fml if lbl.startswith("إبداعية") else f"=IF(TODAY()<${KV}$14,\"\",{fml})"
    if n > 0:
        a, _ = blocks["carried"]
        ws[f"A{a - 1}"] = (f"=\"ثانياً: مهام مرحّلة من أسابيع سابقة لم تُنجز قبل بداية هذا الأسبوع (\"&N(${KV}$13)&\")"
                           f" — للاطلاع، وتُحدَّث حالتها في ورقة أسبوعها\"&IF(N(${KV}$13)>{cfg['carried_rows']},"
                           f"\" — يظهر أقدم {cfg['carried_rows']} منها\",\"\")")
        a, b = blocks["carried"]
        cf(ws, f"A{a - 1}:M{a - 1}", f"${KV}$13>{cfg['carried_rows']}", "F8D0CC", "8C1D18", True)

    # الطباعة والحماية
    ws.print_area = f"A1:M{last_row}"
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_title_rows = "6:7"
    ws.page_margins.left = ws.page_margins.right = 0.3
    protect(ws, pictures=True)
    return ws


def DAY_LABEL(d):
    return d["label"]


# ------------------------------------------------------------------ السجل (مخفي)
def build_log(wb, log_rows):
    ws = wb.create_sheet("السجل")
    ws.sheet_view.rightToLeft = True
    hdr = ["الأسبوع", "المهمة", "يُرحّل", "الحالة", "ترتيب يوم الإنجاز", "ترتيب الموعد",
           "الموعد", "تاريخ الإنجاز", "السرعة", "اسم الأسبوع", "الورقة", "الصف"]
    for i, h in enumerate(hdr, 1):
        ws.cell(1, i, h)
    for i, (n, title, sheet, rr) in enumerate(log_rows, 2):
        q = f"'{sheet}'!"
        ws.cell(i, 1, n)
        ws.cell(i, 2, f"=IF({q}B{rr}=\"\",\"\",{q}B{rr})")
        ws.cell(i, 3, f"={q}D{rr}&\"\"")
        ws.cell(i, 4, f"={q}F{rr}&\"\"")
        ws.cell(i, 5, f"=N({q}{DONE}{rr})")
        ws.cell(i, 6, f"=IF({q}{DL}{rr}=\"\",99999,{q}{DL}{rr})")
        ws.cell(i, 7, f"={q}C{rr}&\"\"")
        ws.cell(i, 8, f"={q}G{rr}&\"\"")
        ws.cell(i, 9, f"={q}{FIN}{rr}&\"\"")
        ws.cell(i, 10, title)
        ws.cell(i, 11, sheet)
        ws.cell(i, 12, rr)
    ws.sheet_state = "hidden"
    return ws


# ------------------------------------------------------------------ الملخص
def build_summary(ws, sem, cfg, name, dept, number, unit):
    ws.title = "الملخص"
    ws.sheet_view.rightToLeft = True
    ws.sheet_properties.tabColor = TEAL
    widths = {"A": 3, "B": 30, "C": 16, "D": 16, "E": 10, "F": 11, "G": 11, "H": 10, "I": 11,
              "J": 9, "K": 9, "L": 9, "M": 10, "N": 10, "O": 12}
    for c, wd in widths.items():
        ws.column_dimensions[c].width = wd
    merge(ws, "B1:O1", "ملخص متابعة مهام عضو هيئة التدريب", f=font(16, True, "FFFFFF"), bg=TEAL)
    ws.row_dimensions[1].height = 32
    info = [("اسم المدرب", name), ("رقم المدرب", number), ("القسم", dept), ("الوحدة التدريبية", unit),
            ("الفصل التدريبي", sem["title"])]
    for i, (lbl, val) in enumerate(info, 3):
        put(ws, f"B{i}", lbl, f=font(bold=True), bg=TEAL_L)
        merge(ws, f"C{i}:F{i}", val, align=RIGHT, locked=(lbl == "الفصل التدريبي"),
              bg=None if lbl == "الفصل التدريبي" else "FFFDF0")
    merge(ws, "H3:O7",
          "• يعبّئ المدرب في ورقة كل أسبوع: الحالة وتاريخ الإنجاز والشاهد.\n"
          "• يعتمد رئيس القسم المنجز، ويعدّل السرعة عند الحاجة مع ذكر السبب.\n"
          "• نسبة الإنجاز = المنجز المعتمد ÷ المطلوب (لا تُحسب «لا ينطبق»).\n"
          "• الخلايا الصفراء تنتظر التعبئة. التفاصيل في ورقة «طريقة التعبئة».",
          f=font(10), align=RIGHT, bg="F7FBFB")

    hdr = ["الأسبوع", "من", "إلى", "المطلوب", "المنجز المعتمد", "بانتظار الاعتماد", "غير منجز", "نسبة الإنجاز",
           "سريع", "متوسط", "ضعيف", "لا يوجد رد", "إبداعية", "مرحّلة غير منجزة"]
    r0 = 9
    for i, h in enumerate(hdr):
        put(ws, f"{get_column_letter(i + 2)}{r0}", h, f=font(10, True, "FFFFFF"), bg=TEAL)
    ws.row_dimensions[r0].height = 32
    src = {"E": 2, "F": 3, "G": 4, "H": 5, "J": 7, "K": 8, "L": 9, "M": 10, "N": 11, "O": 13}
    r = r0 + 1
    for w in sem["weeks"]:
        q = f"'{w['sheet']}'!"
        put(ws, f"B{r}", w["title"], align=RIGHT, f=font(10, True))
        ws[f"B{r}"].hyperlink = f"#'{w['sheet']}'!A1"
        put(ws, f"C{r}", w["days"][0]["hijri"], f=font(10))
        put(ws, f"D{r}", w["days"][-1]["hijri"], f=font(10))
        for col, row in src.items():
            put(ws, f"{col}{r}", f"={q}${KV}${row}", f=font(10))
        put(ws, f"I{r}", f"={q}${KV}$6", f=font(10, True), fmt="0%")
        r += 1
    last = r - 1
    put(ws, f"B{r}", "إجمالي الفصل", f=font(11, True), bg=TEAL_L)
    put(ws, f"C{r}", "", bg=TEAL_L)
    put(ws, f"D{r}", "", bg=TEAL_L)
    for col in "EFGHJKLMNO":
        put(ws, f"{col}{r}", f"=SUM({col}{r0 + 1}:{col}{last})" if col != "O" else "—", f=font(11, True), bg=TEAL_L)
    put(ws, f"I{r}", f"=IF(E{r}=0,\"—\",F{r}/E{r})", f=font(12, True, TEAL), bg=TEAL_L, fmt="0%")
    tot = r
    ws.conditional_formatting.add(f"I{r0 + 1}:I{last}", DataBarRule(start_type="num", start_value=0, end_type="num",
                                                                    end_value=1, color="5AA9B3"))
    r += 2
    merge(ws, f"B{r}:O{r}", "مؤشر بند «إنجاز المهام في الوقت المحدد» (البند 20 في نموذج تقييم الأداء — 4 درجات)",
          f=font(11, True), bg=SECTION, align=RIGHT)
    r += 1
    labels = [("نسبة «سريع» من المهام المقيّمة", "J"), ("نسبة «متوسط»", "K"), ("نسبة «ضعيف»", "L"), ("نسبة «لا يوجد رد»", "M")]
    for lbl, col in labels:
        put(ws, f"B{r}", lbl, f=font(10, True), bg=TEAL_L, align=RIGHT)
        put(ws, f"C{r}", f"=IF(SUM($J${tot}:$M${tot})=0,\"—\",{col}{tot}/SUM($J${tot}:$M${tot}))", fmt="0%", f=font(11, True))
        r += 1
    ws.print_area = f"B1:O{r}"
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1
    protect(ws)


# ------------------------------------------------------------------ طريقة التعبئة
def build_help(wb, cfg):
    ws = wb.create_sheet("طريقة التعبئة")
    ws.sheet_view.rightToLeft = True
    ws.sheet_properties.tabColor = "C9A227"
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 26
    ws.column_dimensions["C"].width = 95
    merge(ws, "B1:C1", "طريقة تعبئة نموذج المتابعة", f=font(15, True, "FFFFFF"), bg=TEAL)
    t = cfg["deadline_time"]
    m = cfg["speed"]["medium_max_delay"]
    rows = [
        ("للمدرب", None),
        ("1", "اكتب اسمك ورقمك وقسمك في ورقة «الملخص» مرة واحدة، وتظهر في كل الأوراق."),
        ("2", "افتح ورقة الأسبوع الحالي. لكل مهمة اختر «الحالة» من القائمة: منجز، جزئي، لم ينجز، لا ينطبق."),
        ("3", "عند الإنجاز اختر «تاريخ الإنجاز» من القائمة (الأيام مكتوبة بالهجري، وأيام الإجازات غير موجودة فيها)."),
        ("4", "ضع «الشاهد»: رابط ملف أو صورة على OneDrive، أو وصفاً مختصراً لما تم. ويمكن إدراج صورة الشاهد في الورقة (إدراج ← صور) داخل حدود سطر المهمة."),
        ("5", "أضف ما قدّمته من عمل إبداعي (ندوة، دورة، ورشة، مبادرة) في قسم «المهام الإبداعية» مع تاريخه وشاهده."),
        ("6", "المهمة غير المنجزة لا تُنقل يدوياً: تظهر تلقائياً في قسم «مهام مرحّلة» في الأسابيع التالية حتى تحدّث حالتها في ورقة أسبوعها الأصلي."),
        ("لرئيس القسم", None),
        ("7", "اختر «معتمد» أو «غير معتمد» لكل مهمة منجزة. المنجز غير المعتمد لا يدخل في نسبة الإنجاز."),
        ("8", "المهام الطارئة: اكتبها في قسم «المهام الطارئة» مع آخر موعد من القائمة، وحدد هل تُرحّل وبند التقييم."),
        ("9", "عند الحاجة غيّر «سرعة الإنجاز» من عمود «تعديل السرعة»، واكتب السبب في الملاحظات."),
        ("10", "شاهدك على المهمة (صورة زيارة، الجدول المعلّق...): ضع رابطه أو وصفه في عمود «شاهد رئيس القسم»، "
               "أو أدرج الصورة نفسها (إدراج ← صور) وضعها داخل حدود سطر المهمة في عمود «شاهد رئيس القسم» حتى يعرف البرنامج أنها تتبع هذه المهمة."),
        ("11", "لإضافة سطر في أي قسم (مهمة ثابتة جديدة، طارئة إضافية، مهمة لهذا المدرب وحده): تحت كل قسم أسطر مخفية جاهزة؛ "
               "حدّد السطرين حولها ← زر الفأرة الأيمن ← «إظهار»، ثم اكتب المهمة وآخر موعدها. لا تُدرج صفاً جديداً حتى لا تضيع المعادلات."),
        ("12", "الصورة المدرجة تزيد حجم الملف؛ صغّرها قبل الإدراج أو استخدم الرابط عند كثرة الصور."),
        ("سرعة الإنجاز", None),
        ("سريع", f"أُنجزت المهمة في يوم آخر موعد أو قبله (الموعد الساعة {t})."),
        ("متوسط", f"تأخرت من يوم إلى {m} أيام عمل بعد الموعد."),
        ("ضعيف", f"تأخرت أكثر من {m} أيام عمل."),
        ("لا يوجد رد", "فات الموعد ولم تُعبّأ الحالة."),
        ("متأخر", "فات الموعد والحالة «جزئي» أو «لم ينجز»: تُعدّ ضمن «لا يوجد رد» في المؤشرات حتى تُنجز، ثم تأخذ سرعتها النهائية."),
        ("بانتظار", "لم يحن الموعد بعد."),
        ("—", "مهمة مستمرة (تُتابَع بالزيارات) أو إبداعية أو «لا ينطبق»: لا تُحسب لها سرعة."),
        ("ملاحظات", None),
        ("أيام العمل", "تُحسب من الأحد إلى الخميس، وتُستبعد الإجازات الرسمية والإضافية حسب التقويم التدريبي وتعميم الإجازات الإضافية."),
        ("الحماية", "الأوراق محمية بلا كلمة مرور حتى لا تتغير المعادلات؛ الخلايا المخصصة للتعبئة مفتوحة."),
        ("الأهمية", "كل مهمة مكتوب بجانبها بند نموذج تقييم الأداء الذي تدخل فيه، والتفاصيل في ورقة «أهمية المهام»."),
    ]
    r = 3
    for a, b in rows:
        if b is None:
            merge(ws, f"B{r}:C{r}", a, f=font(12, True), bg=SECTION, align=RIGHT)
        else:
            put(ws, f"B{r}", a, f=font(11, True), bg=TEAL_L)
            put(ws, f"C{r}", b, align=RIGHT)
            ws.row_dimensions[r].height = 30 if len(b) < 95 else 46
        r += 1
    landscape(ws, 1)
    protect(ws)


# ------------------------------------------------------------------ أهمية المهام
def build_importance(wb, sem, cfg):
    ws = wb.create_sheet("أهمية المهام")
    ws.sheet_view.rightToLeft = True
    ws.sheet_properties.tabColor = "C9A227"
    for c, wd in {"A": 3, "B": 44, "C": 18, "D": 38, "E": 70}.items():
        ws.column_dimensions[c].width = wd
    merge(ws, "B1:E1", "أهمية المهام وارتباطها بنموذج تقييم أداء عضو هيئة التدريب ودليل المدرب",
          f=font(14, True, "FFFFFF"), bg=TEAL)
    for i, h in enumerate(["المهمة", "الأسابيع", "بند نموذج التقييم", "لماذا هي مطلوبة"], 2):
        put(ws, f"{get_column_letter(i)}3", h, f=font(11, True), bg=TEAL_L)
    r = 4
    if not cfg["tasks"]:
        merge(ws, f"B{r}:E{r}", "القالب مفرغ: يكتب رئيس القسم مهام كل أسبوع في ورقته، ويختار بند التقييم لكل مهمة من القائمة.",
              f=font(10), align=RIGHT)
        r += 1
    for t in cfg["tasks"]:
        w = t["weeks"]
        if len(w) == 2:
            wk = f"كل أسبوع ({w[0]}–{w[1]})"
        else:
            wk = "، ".join(sem["by_n"][x]["title"].replace("الأسبوع ", "") for x in w)
        put(ws, f"B{r}", t["title"], align=RIGHT)
        put(ws, f"C{r}", wk, f=font(10))
        put(ws, f"D{r}", eval_label(cfg, t["eval"]), f=font(10), align=RIGHT)
        put(ws, f"E{r}", t.get("why", ""), f=font(10), align=RIGHT)
        ws.row_dimensions[r].height = 34
        r += 1
    r += 1
    merge(ws, f"B{r}:E{r}", "بنود نموذج تقييم أداء عضو هيئة التدريب (المجموع 100)", f=font(12, True), bg=SECTION, align=RIGHT)
    r += 1
    for i, h in enumerate(["البند", "المجال", "الحد الأعلى (أ / ب)"], 2):
        put(ws, f"{get_column_letter(i)}{r}", h, f=font(11, True), bg=TEAL_L)
    r += 1
    for e in cfg["eval_items"]:
        put(ws, f"B{r}", f"{e['n']} - {e['name']}", align=RIGHT, f=font(10, e["n"] == 20))
        put(ws, f"C{r}", e["group"], f=font(10))
        put(ws, f"D{r}", f"{e['a'] if e['a'] is not None else '—'} / {e['b']}", f=font(10))
        if e["n"] == 20:
            for col in "BCD":
                ws[f"{col}{r}"].fill = fill("FFF4CC")
        r += 1
    put(ws, f"B{r + 1}", "المصدر: نموذج تقييم أداء عضو هيئة التدريب، ودليل المدرب (الإدارة العامة لتقويم التدريب، الإصدار الثاني).",
        f=font(9, color="555555"), align=RIGHT, border=False)
    landscape(ws)
    protect(ws)


# ------------------------------------------------------------------ البناء
def build(out, name="", dept="", number="", unit="", sem_id="1448_1", blank=False, password=""):
    """blank: قالب مفرغ بلا مهام معبأة (رئيس القسم يكتب مهامه). password: رقم سري للحماية وهيكل المصنف."""
    global PASSWORD
    PASSWORD = password or ""
    out = Path(out)
    sem = load_semester(sem_id)
    cfg = load_tasks(sem_id)
    if blank:
        cfg = dict(cfg, tasks=[], emergency=[], blank=True)
    wb = Workbook()
    if PASSWORD:
        wb.security = WorkbookProtection(lockStructure=True)
        wb.security.workbookPassword = PASSWORD
    summary = wb.active
    build_help(wb, cfg)
    build_importance(wb, sem, cfg)
    log_rows = []
    # طول السجل التقريبي يُعرف بعد البناء؛ نحجز سقفاً ثابتاً كافياً
    log_cap = 1 + len(sem["weeks"]) * (12 + cfg.get("blank_fixed_rows", 0) + cfg["fixed_spare_rows"]
                                       + cfg["emergency_rows"] + cfg["emergency_spare_rows"]) + 50
    for w in sem["weeks"]:
        build_week(wb, sem, cfg, w, log_rows, log_cap)
    assert len(log_rows) + 1 <= log_cap, "سقف السجل صغير"
    build_summary(summary, sem, cfg, name, dept, number, unit)
    build_calendar(wb, sem, cfg)
    build_log(wb, log_rows)
    wb.active = 0
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", default="")
    ap.add_argument("--dept", default="")
    ap.add_argument("--number", default="")
    ap.add_argument("--unit", default="")
    ap.add_argument("--out", default="")
    ap.add_argument("--blank", action="store_true", help="قالب مفرغ بلا مهام معبأة")
    ap.add_argument("--password", default="")
    a = ap.parse_args()
    default = ("قالب مفرغ لمتابعة مهام عضو هيئة التدريب - الفصل الأول 1448.xlsx" if a.blank
               else "قالب متابعة مهام عضو هيئة التدريب - الفصل الأول 1448.xlsx")
    out = Path(a.out) if a.out else ROOT / "قوالب" / (f"متابعة مهام - {a.name}.xlsx" if a.name else default)
    print(build(out, a.name, a.dept, a.number, a.unit, blank=a.blank, password=a.password))
